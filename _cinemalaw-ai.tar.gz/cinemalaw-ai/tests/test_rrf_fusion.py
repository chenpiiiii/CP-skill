"""RRF融合算法单元测试"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
from src.retrieval.rrf_fusion import RRFFusion
from src.models.search_result import RetrievalResult, SearchSource


class TestRRFFusion:
    """测试RRF融合算法"""

    @pytest.fixture
    def rrf(self):
        return RRFFusion(k=60)

    @pytest.fixture
    def sample_bm25_results(self):
        return [
            RetrievalResult(chunk_id="c1", content="条款A", score=15.0, source=SearchSource.BM25, rank=0),
            RetrievalResult(chunk_id="c2", content="条款B", score=12.0, source=SearchSource.BM25, rank=1),
            RetrievalResult(chunk_id="c3", content="条款C", score=10.0, source=SearchSource.BM25, rank=2),
        ]

    @pytest.fixture
    def sample_vector_results(self):
        return [
            RetrievalResult(chunk_id="c2", content="条款B", score=0.95, source=SearchSource.VECTOR, rank=0),
            RetrievalResult(chunk_id="c4", content="条款D", score=0.90, source=SearchSource.VECTOR, rank=1),
            RetrievalResult(chunk_id="c1", content="条款A", score=0.85, source=SearchSource.VECTOR, rank=2),
        ]

    def test_basic_fusion(self, rrf, sample_bm25_results, sample_vector_results):
        """测试基本融合功能"""
        results = rrf.fuse(sample_bm25_results, sample_vector_results)
        assert len(results) > 0

        # c1和c2同时出现在两路中，应获得更高RRF分数
        chunk_ids = [r.chunk_id for r in results]
        # c2在BM25排第2、vector排第1，应排名靠前
        assert "c2" in chunk_ids
        assert "c1" in chunk_ids

    def test_rrf_formula(self, rrf):
        """测试RRF公式正确性"""
        bm25 = [RetrievalResult(chunk_id="x", content="test", score=10.0, source=SearchSource.BM25, rank=0)]
        vector = [RetrievalResult(chunk_id="x", content="test", score=0.9, source=SearchSource.VECTOR, rank=0)]

        results = rrf.fuse(bm25, vector)
        assert len(results) == 1

        # RRF = 1/(60+1) + 1/(60+1) = 2/61 ≈ 0.032787
        expected_rrf = 1.0 / 61 + 1.0 / 61
        assert abs(results[0].rrf_score - expected_rrf) < 1e-6

    def test_single_source(self, rrf, sample_bm25_results):
        """测试仅有一路结果时的融合"""
        results = rrf.fuse(sample_bm25_results, [])
        assert len(results) == len(sample_bm25_results)

        # 仅有BM25来源
        for r in results:
            assert r.bm25_rank is not None
            assert r.vector_rank is None

    def test_empty_input(self, rrf):
        """测试空输入"""
        results = rrf.fuse([], [])
        assert len(results) == 0

    def test_deduplication(self, rrf):
        """测试去重逻辑"""
        bm25 = [RetrievalResult(chunk_id="same", content="test", score=10.0, source=SearchSource.BM25, rank=0)]
        vector = [RetrievalResult(chunk_id="same", content="test", score=0.9, source=SearchSource.VECTOR, rank=0)]

        results = rrf.fuse(bm25, vector)
        # 同一chunk_id应只出现一次
        chunk_ids = [r.chunk_id for r in results]
        assert chunk_ids.count("same") == 1
        # 且RRF分数应包含两路贡献
        assert results[0].bm25_rank == 1
        assert results[0].vector_rank == 1

    def test_weighted_fusion(self):
        """测试加权融合"""
        rrf = RRFFusion(k=60, bm25_weight=2.0, vector_weight=1.0)
        bm25 = [RetrievalResult(chunk_id="x", content="test", score=10.0, source=SearchSource.BM25, rank=0)]
        vector = [RetrievalResult(chunk_id="y", content="test", score=0.9, source=SearchSource.VECTOR, rank=0)]

        results = rrf.fuse(bm25, vector)
        # x的RRF = 2/(60+1) ≈ 0.0328
        # y的RRF = 1/(60+1) ≈ 0.0164
        x_result = next(r for r in results if r.chunk_id == "x")
        y_result = next(r for r in results if r.chunk_id == "y")
        assert x_result.rrf_score > y_result.rrf_score

    def test_explain(self, rrf):
        """测试分数解释"""
        explanation = rrf.explain("test_chunk", bm25_rank=1, vector_rank=3)
        assert "BM25" in explanation
        assert "Vector" in explanation
        assert "总分" in explanation


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
