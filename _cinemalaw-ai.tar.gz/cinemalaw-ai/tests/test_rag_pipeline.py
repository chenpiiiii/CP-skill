"""RAG管道端到端测试"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
import asyncio
from src.generation.rag_pipeline import RAGPipeline


class TestRAGPipeline:
    """测试RAG管道"""

    @pytest.fixture
    def rag(self):
        return RAGPipeline(use_mock=True)

    def test_query_sync(self, rag):
        """测试同步查询"""
        response = asyncio.get_event_loop().run_until_complete(
            rag.query("演员的票房分成比例是多少？", mode="review")
        )
        assert response.query == "演员的票房分成比例是多少？"
        assert len(response.answer) > 0
        assert response.confidence is not None

    def test_query_modes(self, rag):
        """测试不同模式"""
        for mode in ["default", "review", "conflict_detection"]:
            response = asyncio.get_event_loop().run_until_complete(
                rag.query("测试问题", mode=mode)
            )
            assert response.answer_type == mode

    def test_response_structure(self, rag):
        """测试响应结构完整性"""
        response = asyncio.get_event_loop().run_until_complete(
            rag.query("违约金是多少？")
        )
        assert hasattr(response, "query")
        assert hasattr(response, "answer")
        assert hasattr(response, "confidence")
        assert hasattr(response, "citations")
        assert hasattr(response, "generation_time_ms")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
