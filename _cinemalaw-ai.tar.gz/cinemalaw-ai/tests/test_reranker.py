"""Reranker单元测试"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
from src.retrieval.reranker import Reranker
from src.models.search_result import RRFResult


class TestReranker:
    """测试重排器"""

    @pytest.fixture
    def reranker(self):
        return Reranker(use_mock=True)

    @pytest.fixture
    def sample_candidates(self):
        return [
            RRFResult(chunk_id="c1", content="演员报酬条款：甲方支付片酬100万元", rrf_score=0.03),
            RRFResult(chunk_id="c2", content="知识产权归属：著作权归甲方所有", rrf_score=0.025),
            RRFResult(chunk_id="c3", content="票房分成：超出5亿部分2%", rrf_score=0.02),
        ]

    def test_basic_rerank(self, reranker, sample_candidates):
        """测试基本重排功能"""
        results = reranker.rerank("演员片酬是多少", sample_candidates, top_k=3)
        assert len(results) > 0
        assert len(results) <= 3

    def test_threshold_filtering(self, reranker, sample_candidates):
        """测试阈值过滤"""
        results = reranker.rerank("test", sample_candidates, top_k=10, threshold=0.99)
        # 高阈值应过滤掉大部分结果
        assert len(results) <= len(sample_candidates)

    def test_score_ordering(self, reranker, sample_candidates):
        """测试分数排序（降序）"""
        results = reranker.rerank("test query", sample_candidates, top_k=10)
        if len(results) >= 2:
            for i in range(len(results) - 1):
                assert results[i].rerank_score >= results[i + 1].rerank_score

    def test_empty_candidates(self, reranker):
        """测试空候选列表"""
        results = reranker.rerank("test", [], top_k=5)
        assert len(results) == 0

    def test_top_k_limit(self, reranker, sample_candidates):
        """测试top_k限制"""
        results = reranker.rerank("test", sample_candidates, top_k=2)
        assert len(results) <= 2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
