"""层级切片算法单元测试"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
from src.ingestion.chunking import HierarchyChunker, ChunkingConfig


class TestHierarchyChunker:
    """测试层级切片器"""

    @pytest.fixture
    def chunker(self):
        return HierarchyChunker(ChunkingConfig(chunk_size_tokens=100, chunk_overlap_tokens=20))

    @pytest.fixture
    def sample_legal_text(self):
        return """第一章 总则
第一条 本合同由甲方与乙方共同签订。
第二条 双方应遵循平等互利的原则。

第二章 报酬条款
第三条 甲方应向乙方支付报酬总额为人民币壹佰万元整。
第四条 付款方式分三期：签约时支付30%，开机时支付40%，杀青时支付30%。

第三章 知识产权
第五条 乙方在本项目中产生的表演成果，其著作权归甲方所有。"""

    def test_basic_chunking(self, chunker, sample_legal_text):
        """测试基本切片功能"""
        batch = chunker.chunk_document(
            text=sample_legal_text,
            document_id="test_doc_001",
            document_name="测试合同.pdf",
        )

        assert batch.total_chunks > 0
        assert batch.document_id == "test_doc_001"
        assert all(c.document_id == "test_doc_001" for c in batch.chunks)

    def test_hierarchy_detection(self, chunker, sample_legal_text):
        """测试层级结构识别"""
        segments = chunker._identify_hierarchy(sample_legal_text)
        # 应该识别出至少5个段落（3章+5条或更多）
        assert len(segments) >= 3

        # 检查章级段落的层级
        chapter_segments = [s for s in segments if s.level_type == "chapter"]
        assert len(chapter_segments) >= 2  # 至少识别出"第一章"和"第二章"

    def test_hierarchy_paths(self, chunker, sample_legal_text):
        """测试层级路径构建"""
        batch = chunker.chunk_document(
            text=sample_legal_text,
            document_id="test_doc_001",
        )

        # 至少部分chunks应该有层级路径
        chunks_with_path = [c for c in batch.chunks if c.hierarchy_path]
        assert len(chunks_with_path) > 0

    def test_empty_text(self, chunker):
        """测试空文本处理"""
        batch = chunker.chunk_document(text="", document_id="test_empty")
        assert batch.total_chunks == 0

    def test_single_article(self, chunker):
        """测试单条文本"""
        text = "第一条 本合同由甲方与乙方共同签订。"
        batch = chunker.chunk_document(text=text, document_id="test_single")
        assert batch.total_chunks >= 1

    def test_token_estimation(self, chunker):
        """测试token估算"""
        text = "这是一段测试文本，用于验证token估算功能。" * 10
        tokens = chunker.estimate_tokens(text)
        assert tokens > 0
        assert tokens < len(text)  # token数应小于字符数


class TestChunkingConfig:
    """测试切片配置"""

    def test_default_config(self):
        config = ChunkingConfig()
        assert config.chunk_size_tokens == 600
        assert config.chunk_overlap_tokens == 120
        assert config.min_chunk_size_tokens == 50

    def test_custom_config(self):
        config = ChunkingConfig(chunk_size_tokens=400, chunk_overlap_tokens=80)
        assert config.chunk_size_tokens == 400
        assert config.chunk_overlap_tokens == 80


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
