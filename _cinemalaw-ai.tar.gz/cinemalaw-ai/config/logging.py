"""
影律通（Cinemalaw AI）日志配置模块

提供统一的日志格式和输出配置，支持结构化日志输出。
"""

import logging
import sys
from pathlib import Path
from typing import Optional

from config.settings import get_settings


LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s:%(lineno)d | %(message)s"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def setup_logging(
    log_level: Optional[str] = None,
    log_file: Optional[str] = None,
) -> None:
    """
    初始化全局日志配置。

    Args:
        log_level: 日志级别，默认从配置读取
        log_file: 日志文件路径，不传则仅输出到控制台
    """
    settings = get_settings()
    level = log_level or settings.app_log_level
    numeric_level = getattr(logging, level.upper(), logging.INFO)

    # 获取根日志记录器
    root_logger = logging.getLogger()
    root_logger.setLevel(numeric_level)

    # 清除已有handler，避免重复添加
    root_logger.handlers.clear()

    # 控制台输出handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(numeric_level)
    console_formatter = logging.Formatter(LOG_FORMAT, datefmt=LOG_DATE_FORMAT)
    console_handler.setFormatter(console_formatter)
    root_logger.addHandler(console_handler)

    # 文件输出handler（可选）
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setLevel(numeric_level)
        file_formatter = logging.Formatter(LOG_FORMAT, datefmt=LOG_DATE_FORMAT)
        file_handler.setFormatter(file_formatter)
        root_logger.addHandler(file_handler)

    # 降低第三方库日志级别，减少噪音
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("elasticsearch").setLevel(logging.WARNING)
    logging.getLogger("pymilvus").setLevel(logging.WARNING)
    logging.getLogger("transformers").setLevel(logging.WARNING)

    root_logger.info("日志系统初始化完成，级别: %s", level)


def get_logger(name: str) -> logging.Logger:
    """
    获取指定名称的logger实例。

    Args:
        name: logger名称，通常使用 __name__

    Returns:
        配置好的Logger实例
    """
    return logging.getLogger(name)
