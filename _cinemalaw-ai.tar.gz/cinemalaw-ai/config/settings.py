"""
影律通（Cinemalaw AI）全局配置模块

使用 pydantic-settings 管理所有配置项，支持环境变量覆盖。
配置文件路径和优先级：.env文件 > 环境变量 > 默认值
"""

from pathlib import Path
from typing import Optional, List
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class AppSettings(BaseSettings):
    """应用基础配置"""
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # 应用基础
    app_name: str = Field(default="cinemalaw-ai", description="应用名称")
    app_env: str = Field(default="development", description="运行环境")
    app_debug: bool = Field(default=True, description="调试模式")
    app_host: str = Field(default="0.0.0.0", description="监听地址")
    app_port: int = Field(default=8000, description="监听端口")
    app_log_level: str = Field(default="INFO", description="日志级别")

    # Elasticsearch
    es_host: str = Field(default="localhost", description="ES主机地址")
    es_port: int = Field(default=9200, description="ES端口")
    es_scheme: str = Field(default="http", description="ES协议")
    es_username: str = Field(default="elastic", description="ES用户名")
    es_password: str = Field(default="changeme", description="ES密码")
    es_index_prefix: str = Field(default="cinemalaw", description="ES索引前缀")
    es_chunk_size: int = Field(default=500, description="ES批量写入大小")
    es_timeout: int = Field(default=30, description="ES超时时间（秒）")

    @property
    def es_url(self) -> str:
        """构建ES完整URL"""
        return f"{self.es_scheme}://{self.es_host}:{self.es_port}"

    # Milvus
    milvus_host: str = Field(default="localhost", description="Milvus主机地址")
    milvus_port: int = Field(default=19530, description="Milvus端口")
    milvus_collection: str = Field(default="cinemalaw_chunks", description="Milvus集合名")
    milvus_dim: int = Field(default=1024, description="向量维度")
    milvus_metric: str = Field(default="COSINE", description="距离度量方式")
    milvus_index_type: str = Field(default="IVF_FLAT", description="索引类型")
    milvus_nlist: int = Field(default=1024, description="IVF聚类中心数")
    milvus_nprobe: int = Field(default=16, description="查询时搜索的聚类中心数")

    @property
    def milvus_uri(self) -> str:
        """构建Milvus URI"""
        return f"{self.milvus_host}:{self.milvus_port}"

    # BGE-M3 Embedding
    bge_m3_model_path: str = Field(default="/models/bge-m3", description="BGE-M3模型路径")
    bge_m3_use_gpu: bool = Field(default=True, description="是否使用GPU")
    bge_m3_gpu_id: int = Field(default=0, description="GPU设备ID")
    bge_m3_batch_size: int = Field(default=32, description="批量编码大小")
    bge_m3_max_length: int = Field(default=8192, description="最大输入长度")
    bge_m3_endpoint: str = Field(default="", description="远程推理服务地址")
    bge_m3_use_remote: bool = Field(default=False, description="是否使用远程推理服务")

    # BGE-Reranker
    reranker_model_path: str = Field(default="/models/bge-reranker-large", description="Reranker模型路径")
    reranker_use_gpu: bool = Field(default=True, description="是否使用GPU")
    reranker_gpu_id: int = Field(default=0, description="GPU设备ID")
    reranker_threshold: float = Field(default=0.35, description="重排分数阈值")
    reranker_top_k: int = Field(default=5, description="最终返回条数")
    reranker_endpoint: str = Field(default="", description="远程推理服务地址")
    reranker_use_remote: bool = Field(default=False, description="是否使用远程推理服务")

    # LLM 配置
    llm_provider: str = Field(default="claude", description="LLM提供商: claude / deepseek")

    claude_api_key: str = Field(default="", description="Claude API Key")
    claude_model: str = Field(default="claude-3-5-sonnet-20241022", description="Claude模型")
    claude_max_tokens: int = Field(default=4096, description="Claude最大输出token")
    claude_temperature: float = Field(default=0.1, description="Claude温度参数")

    deepseek_api_key: str = Field(default="", description="DeepSeek API Key")
    deepseek_model: str = Field(default="deepseek-chat", description="DeepSeek模型")
    deepseek_base_url: str = Field(default="https://api.deepseek.com/v1", description="DeepSeek API地址")
    deepseek_max_tokens: int = Field(default=4096, description="DeepSeek最大输出token")
    deepseek_temperature: float = Field(default=0.1, description="DeepSeek温度参数")

    # LayoutLM
    layoutlm_model_path: str = Field(default="/models/layoutlm-v3", description="LayoutLM模型路径")
    layoutlm_use_gpu: bool = Field(default=True, description="是否使用GPU")
    layoutlm_gpu_id: int = Field(default=0, description="GPU设备ID")
    layoutlm_endpoint: str = Field(default="", description="远程推理服务地址")
    layoutlm_use_remote: bool = Field(default=False, description="是否使用远程推理服务")

    # RAGAS 评估
    ragas_judge_llm: str = Field(default="claude", description="RAGAS评估使用的LLM")
    ragas_eval_batch_size: int = Field(default=10, description="评估批量大小")

    # 文档处理
    max_upload_size_mb: int = Field(default=50, description="最大上传文件大小(MB)")
    chunk_size_tokens: int = Field(default=600, description="切片目标token数")
    chunk_overlap_tokens: int = Field(default=120, description="切片重叠token数")
    supported_formats: str = Field(default="pdf,docx,png,jpg,jpeg,tiff", description="支持的文件格式")

    @property
    def supported_format_list(self) -> List[str]:
        """获取支持格式列表"""
        return [f.strip() for f in self.supported_formats.split(",")]

    # Redis
    redis_host: str = Field(default="localhost", description="Redis主机")
    redis_port: int = Field(default=6379, description="Redis端口")
    redis_db: int = Field(default=0, description="Redis数据库编号")
    redis_password: str = Field(default="", description="Redis密码")

    # 对象存储
    s3_endpoint: str = Field(default="", description="S3兼容存储端点")
    s3_access_key: str = Field(default="", description="S3访问密钥")
    s3_secret_key: str = Field(default="", description="S3秘密密钥")
    s3_bucket: str = Field(default="cinemalaw-documents", description="S3存储桶")
    s3_region: str = Field(default="cn-beijing", description="S3区域")


# 全局配置单例
_settings: Optional[AppSettings] = None


def get_settings() -> AppSettings:
    """获取全局配置实例（懒加载单例）"""
    global _settings
    if _settings is None:
        _settings = AppSettings()
    return _settings


def reload_settings() -> AppSettings:
    """重新加载配置（用于测试或热更新）"""
    global _settings
    _settings = AppSettings()
    return _settings
