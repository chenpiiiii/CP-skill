"""API请求/响应数据模型"""

from __future__ import annotations

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


class DocumentUploadRequest(BaseModel):
    """文档上传请求"""
    document_type: str = Field(default="other", description="文档类型")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="额外元数据")


class DocumentStatusResponse(BaseModel):
    """文档处理状态响应"""
    document_id: str
    status: str
    document_name: str = ""
    total_chunks: int = 0
    total_tokens: int = 0
    processing_time_seconds: float = 0.0
    errors: List[str] = Field(default_factory=list)


class SearchRequest(BaseModel):
    """检索请求"""
    query: str = Field(description="查询文本")
    top_k: int = Field(default=5, ge=1, le=50, description="返回条数")
    candidate_size: int = Field(default=30, ge=10, le=100, description="候选数量")
    metadata_filter: Optional[Dict[str, Any]] = Field(default=None, description="元数据过滤")
    enable_rerank: bool = Field(default=True, description="是否启用重排")


class SearchResponse(BaseModel):
    """检索响应"""
    query: str
    results: List[Dict[str, Any]]
    total_candidates: int = 0
    search_time_ms: float = 0.0


class QueryRequest(BaseModel):
    """RAG问答请求"""
    question: str = Field(description="用户问题")
    mode: str = Field(default="default", description="模式: default/review/conflict_detection")
    top_k: int = Field(default=5, ge=1, le=20, description="上下文条数")
    metadata_filter: Optional[Dict[str, Any]] = Field(default=None, description="元数据过滤")


class QueryResponse(BaseModel):
    """RAG问答响应"""
    query: str
    answer: str
    confidence: str = ""
    citations: List[Dict[str, Any]] = Field(default_factory=list)
    findings: List[Dict[str, Any]] = Field(default_factory=list)
    generation_time_ms: float = 0.0
    model_used: str = ""


class EvaluationRequest(BaseModel):
    """评估请求"""
    samples: List[Dict[str, Any]] = Field(description="评估样本列表")


class EvaluationResponse(BaseModel):
    """评估响应"""
    summary: Dict[str, Any]
    total_samples: int = 0
