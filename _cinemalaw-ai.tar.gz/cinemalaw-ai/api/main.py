"""
FastAPI 应用入口

影律通（Cinemalaw AI）API服务入口文件。
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from config.settings import get_settings
from config.logging import setup_logging

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    # 启动时
    settings = get_settings()
    setup_logging(log_level=settings.app_log_level)
    logger.info("影律通（Cinemalaw AI）API服务启动中...")
    logger.info("环境: %s, 调试: %s", settings.app_env, settings.app_debug)
    yield
    # 关闭时
    logger.info("影律通API服务关闭")


def create_app() -> FastAPI:
    """创建并配置FastAPI应用"""
    settings = get_settings()

    app = FastAPI(
        title="影律通 Cinemalaw AI",
        description="影视行业合同与版权合规智能审查系统 API",
        version="1.0.0",
        lifespan=lifespan,
    )

    # CORS中间件
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # 全局异常处理
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        logger.error("未处理异常: %s", exc, exc_info=True)
        return JSONResponse(
            status_code=500,
            content={"error": "内部服务器错误", "detail": str(exc) if settings.app_debug else "请稍后重试"},
        )

    # 注册路由
    from api.routes.ingestion import router as ingestion_router
    from api.routes.search import router as search_router
    from api.routes.evaluation import router as evaluation_router

    app.include_router(ingestion_router, prefix="/api/v1", tags=["文档处理"])
    app.include_router(search_router, prefix="/api/v1", tags=["检索与问答"])
    app.include_router(evaluation_router, prefix="/api/v1", tags=["评估"])

    # 健康检查
    @app.get("/health")
    async def health_check():
        return {"status": "healthy", "service": "cinemalaw-ai", "version": "1.0.0"}

    @app.get("/")
    async def root():
        return {
            "service": "影律通 Cinemalaw AI",
            "version": "1.0.0",
            "docs": "/docs",
            "health": "/health",
        }

    return app


app = create_app()
