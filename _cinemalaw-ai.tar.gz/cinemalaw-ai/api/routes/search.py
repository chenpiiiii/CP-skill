"""检索与问答API路由"""

from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, HTTPException

from api.schemas.api_schemas import SearchRequest, SearchResponse, QueryRequest, QueryResponse
from src.retrieval.hybrid_search import HybridSearcher
from src.generation.rag_pipeline import RAGPipeline

logger = logging.getLogger(__name__)
router = APIRouter()

# 全局实例
_searcher: Optional[HybridSearcher] = None
_rag: Optional[RAGPipeline] = None


def get_searcher() -> HybridSearcher:
    global _searcher
    if _searcher is None:
        _searcher = HybridSearcher(use_mock=True)
    return _searcher


def get_rag() -> RAGPipeline:
    global _rag
    if _rag is None:
        _rag = RAGPipeline(use_mock=True)
    return _rag


@router.post("/search", response_model=SearchResponse)
async def search(request: SearchRequest):
    """执行混合检索"""
    try:
        searcher = get_searcher()
        result = searcher.search(
            query=request.query,
            top_k=request.top_k,
            candidate_size=request.candidate_size,
            metadata_filter=request.metadata_filter,
            enable_rerank=request.enable_rerank,
        )
        return SearchResponse(
            query=result.query,
            results=[
                {
                    "chunk_id": r.chunk_id,
                    "content": r.content[:300],
                    "rerank_score": r.rerank_score,
                    "document_name": r.document_name,
                    "hierarchy_path": r.hierarchy_path,
                    "page_range": r.page_range,
                    "rank": r.rank,
                }
                for r in result.results
            ],
            total_candidates=result.total_candidates,
            search_time_ms=result.search_time_ms,
        )
    except Exception as e:
        logger.error("检索失败: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"检索失败: {str(e)}")


@router.post("/query", response_model=QueryResponse)
async def query(request: QueryRequest):
    """执行RAG问答"""
    try:
        rag = get_rag()
        response = await rag.query(
            question=request.question,
            mode=request.mode,
            top_k=request.top_k,
            metadata_filter=request.metadata_filter,
        )
        return QueryResponse(
            query=response.query,
            answer=response.answer,
            confidence=response.confidence.value,
            citations=[
                {
                    "citation_id": c.citation_id,
                    "chunk_id": c.chunk_id,
                    "document_name": c.document_name,
                    "hierarchy_path": c.hierarchy_path,
                    "page_range": c.page_range,
                    "relevant_text": c.relevant_text,
                    "relevance_score": c.relevance_score,
                }
                for c in response.citations
            ],
            findings=[
                {
                    "finding_id": f.finding_id,
                    "severity": f.severity,
                    "category": f.category,
                    "description": f.description,
                    "confidence": f.confidence.value,
                }
                for f in response.findings
            ],
            generation_time_ms=response.generation_time_ms,
            model_used=response.model_used,
        )
    except Exception as e:
        logger.error("RAG问答失败: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"问答失败: {str(e)}")


@router.get("/chunks/{chunk_id}")
async def get_chunk_detail(chunk_id: str):
    """获取Chunk详情（用于溯源）"""
    # 实际实现应从ES/Milvus中查询
    return {
        "chunk_id": chunk_id,
        "content": f"[Chunk详情占位] chunk_id={chunk_id}",
        "document_name": "模拟文档.pdf",
        "hierarchy_path": "第三章-报酬条款 / 3.2-分成比例",
        "page_range": [2, 3],
        "message": "实际实现需从索引中查询",
    }
