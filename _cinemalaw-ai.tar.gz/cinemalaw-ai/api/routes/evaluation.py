"""评估API路由"""

from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, HTTPException

from api.schemas.api_schemas import EvaluationRequest, EvaluationResponse
from src.evaluation.evaluator import RAGASEvaluator

logger = logging.getLogger(__name__)
router = APIRouter()

_evaluator: Optional[RAGASEvaluator] = None
_last_results: dict = {}


def get_evaluator() -> RAGASEvaluator:
    global _evaluator
    if _evaluator is None:
        _evaluator = RAGASEvaluator()
    return _evaluator


@router.post("/evaluation/run", response_model=EvaluationResponse)
async def run_evaluation(request: EvaluationRequest):
    """运行RAGAS评估"""
    try:
        evaluator = get_evaluator()
        summary = evaluator.evaluate_batch(request.samples)
        _last_results.update(summary)

        return EvaluationResponse(
            summary=summary,
            total_samples=len(request.samples),
        )
    except Exception as e:
        logger.error("评估运行失败: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"评估失败: {str(e)}")


@router.get("/evaluation/results")
async def get_evaluation_results():
    """获取最近一次评估结果"""
    if not _last_results:
        return {"message": "暂无评估结果", "results": {}}
    return {"results": _last_results}
