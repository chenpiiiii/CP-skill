"""文档上传与解析API路由"""

from __future__ import annotations

import uuid
import logging
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, UploadFile, File, Form, HTTPException

from api.schemas.api_schemas import DocumentStatusResponse
from src.ingestion.pipeline import IngestionPipeline, PipelineResult

logger = logging.getLogger(__name__)
router = APIRouter()

# 全局管道实例（实际生产环境应使用依赖注入）
_pipeline: Optional[IngestionPipeline] = None
# 简化的结果缓存
_results_cache: dict = {}


def get_pipeline() -> IngestionPipeline:
    global _pipeline
    if _pipeline is None:
        _pipeline = IngestionPipeline(use_mock=True)
    return _pipeline


@router.post("/documents/upload", response_model=DocumentStatusResponse)
async def upload_document(
    file: UploadFile = File(...),
    document_type: str = Form(default="other"),
):
    """
    上传并解析文档。

    接收PDF/DOCX/图片文件，执行解析→切片→标注流程。
    """
    from config.settings import get_settings
    settings = get_settings()

    # 验证文件格式
    suffix = Path(file.filename or "").suffix.lower().lstrip(".")
    if suffix not in settings.supported_format_list:
        raise HTTPException(status_code=400, detail=f"不支持的文件格式: {suffix}")

    # 保存上传文件
    upload_dir = Path("/tmp/cinemalaw_uploads")
    upload_dir.mkdir(parents=True, exist_ok=True)
    file_path = upload_dir / f"{uuid.uuid4()}_{file.filename}"

    try:
        content = await file.read()
        with open(file_path, "wb") as f:
            f.write(content)

        # 执行解析管道
        pipeline = get_pipeline()
        from src.models.document import DocumentType
        doc_type = DocumentType(document_type) if document_type in [e.value for e in DocumentType] else DocumentType.OTHER

        result = pipeline.process_document(str(file_path), doc_type)

        # 缓存结果
        _results_cache[result.document_id] = result

        return DocumentStatusResponse(
            document_id=result.document_id,
            status=result.status.value,
            document_name=result.document_name,
            total_chunks=result.total_chunks,
            total_tokens=result.total_tokens,
            processing_time_seconds=result.processing_time_seconds,
            errors=result.errors,
        )

    except Exception as e:
        logger.error("文档上传失败: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"文档处理失败: {str(e)}")


@router.get("/documents/{document_id}/status", response_model=DocumentStatusResponse)
async def get_document_status(document_id: str):
    """查询文档处理状态"""
    result = _results_cache.get(document_id)
    if result is None:
        raise HTTPException(status_code=404, detail=f"文档不存在: {document_id}")

    return DocumentStatusResponse(
        document_id=result.document_id,
        status=result.status.value,
        document_name=result.document_name,
        total_chunks=result.total_chunks,
        total_tokens=result.total_tokens,
        processing_time_seconds=result.processing_time_seconds,
        errors=result.errors,
    )
