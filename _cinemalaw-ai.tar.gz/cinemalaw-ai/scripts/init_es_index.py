"""
初始化Elasticsearch索引

创建影律通所需的ES索引，配置IK中文分词器和字段mapping。
使用方法: python scripts/init_es_index.py
"""

import sys
import logging
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from config.settings import get_settings
from config.logging import setup_logging

logger = logging.getLogger(__name__)

# ES索引Settings配置
INDEX_SETTINGS = {
    "settings": {
        "number_of_shards": 1,
        "number_of_replicas": 0,
        "analysis": {
            "analyzer": {
                "cinemalaw_analyzer": {
                    "type": "custom",
                    "tokenizer": "ik_smart",
                    "filter": ["lowercase", "cinemalaw_synonym"],
                },
            },
            "filter": {
                "cinemalaw_synonym": {
                    "type": "synonym",
                    "synonyms": [
                        "报酬,片酬,酬金,费用",
                        "版权,著作权,知识产权",
                        "违约,违反合同,毁约",
                        "票房,票房收入,票房分成",
                    ],
                },
            },
        },
    },
    "mappings": {
        "properties": {
            "chunk_id": {"type": "keyword"},
            "document_id": {"type": "keyword"},
            "document_name": {"type": "text", "analyzer": "ik_smart"},
            "content": {
                "type": "text",
                "analyzer": "cinemalaw_analyzer",
                "fields": {
                    "keyword": {"type": "keyword", "ignore_above": 256},
                },
            },
            "hierarchy_path": {"type": "text", "analyzer": "ik_smart"},
            "hierarchy_level": {"type": "integer"},
            "category": {"type": "keyword"},
            "keywords": {"type": "keyword"},
            "chunk_index": {"type": "integer"},
            "token_count": {"type": "integer"},
            "page_range": {"type": "integer_range"},
            "timestamp": {"type": "date"},
        },
    },
}


def init_es_index():
    """初始化ES索引"""
    setup_logging()
    settings = get_settings()
    index_name = f"{settings.es_index_prefix}_chunks"

    logger.info("正在初始化ES索引: %s", index_name)
    logger.info("ES地址: %s", settings.es_url)

    try:
        from elasticsearch import Elasticsearch

        client = Elasticsearch(
            settings.es_url,
            basic_auth=(settings.es_username, settings.es_password),
        )

        # 检查连接
        info = client.info()
        logger.info("ES版本: %s", info.get("version", {}).get("number"))

        # 删除已有索引
        if client.indices.exists(index=index_name):
            logger.info("删除已有索引: %s", index_name)
            client.indices.delete(index=index_name)

        # 创建新索引
        client.indices.create(index=index_name, body=INDEX_SETTINGS)
        logger.info("索引创建成功: %s", index_name)

        # 验证
        mapping = client.indices.get_mapping(index=index_name)
        logger.info("索引mapping验证通过")

        print(f"✅ ES索引 '{index_name}' 初始化成功")

    except ImportError:
        print("❌ 请先安装 elasticsearch 库: pip install elasticsearch")
    except Exception as e:
        logger.error("ES索引初始化失败: %s", e)
        print(f"❌ ES索引初始化失败: {e}")
        print("提示: 确保ES服务已启动，且地址/密码配置正确")


if __name__ == "__main__":
    init_es_index()
