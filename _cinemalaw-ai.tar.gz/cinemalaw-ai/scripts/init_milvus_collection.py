"""
初始化Milvus集合

创建影律通所需的Milvus向量集合，定义向量维度和元数据字段。
使用方法: python scripts/init_milvus_collection.py
"""

import sys
import logging
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from config.settings import get_settings
from config.logging import setup_logging

logger = logging.getLogger(__name__)


def init_milvus_collection():
    """初始化Milvus集合"""
    setup_logging()
    settings = get_settings()

    logger.info("正在初始化Milvus集合: %s", settings.milvus_collection)
    logger.info("Milvus地址: %s", settings.milvus_uri)

    try:
        from pymilvus import connections, Collection, FieldSchema, DataType, CollectionSchema

        # 连接Milvus
        connections.connect(host=settings.milvus_host, port=settings.milvus_port)
        logger.info("Milvus连接成功")

        # 定义字段Schema
        fields = [
            FieldSchema(name="chunk_id", dtype=DataType.VARCHAR, is_primary=True, max_length=64),
            FieldSchema(name="embedding", dtype=DataType.FLOAT_VECTOR, dim=settings.milvus_dim),
            FieldSchema(name="content", dtype=DataType.VARCHAR, max_length=8192),
            FieldSchema(name="document_id", dtype=DataType.VARCHAR, max_length=64),
            FieldSchema(name="document_name", dtype=DataType.VARCHAR, max_length=256),
            FieldSchema(name="hierarchy_path", dtype=DataType.VARCHAR, max_length=512),
            FieldSchema(name="category", dtype=DataType.VARCHAR, max_length=64),
        ]

        schema = CollectionSchema(fields=fields, description="影律通合同Chunk向量集合")

        # 删除已有集合
        if Collection(settings.milvus_collection).exists():
            logger.info("删除已有集合: %s", settings.milvus_collection)
            Collection(settings.milvus_collection).drop()

        # 创建集合
        collection = Collection(name=settings.milvus_collection, schema=schema)
        logger.info("集合创建成功: %s", settings.milvus_collection)

        # 创建向量索引
        index_params = {
            "index_type": settings.milvus_index_type,
            "metric_type": settings.milvus_metric,
            "params": {"nlist": settings.milvus_nlist},
        }
        collection.create_index(field_name="embedding", index_params=index_params)
        logger.info("向量索引创建成功: %s", index_params)

        print(f"✅ Milvus集合 '{settings.milvus_collection}' 初始化成功")
        print(f"   向量维度: {settings.milvus_dim}")
        print(f"   索引类型: {settings.milvus_index_type}")
        print(f"   距离度量: {settings.milvus_metric}")

    except ImportError:
        print("❌ 请先安装 pymilvus 库: pip install pymilvus")
    except Exception as e:
        logger.error("Milvus集合初始化失败: %s", e)
        print(f"❌ Milvus集合初始化失败: {e}")
        print("提示: 确保Milvus服务已启动")


if __name__ == "__main__":
    init_milvus_collection()
