"""
运行RAGAS评估

执行评估样本并生成评估报告。
使用方法: python scripts/run_evaluation.py
"""

import sys
import logging
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from config.logging import setup_logging
from src.evaluation.evaluator import RAGASEvaluator
from src.evaluation.report_generator import ReportGenerator

logger = logging.getLogger(__name__)

# 示例评估样本
SAMPLE_EVALUATION_DATA = [
    {
        "question": "演员的票房分成比例是多少？",
        "answer": "根据合同第九条约定，若影片票房收入超过5亿元，乙方额外获得超出部分2%的票房分成。",
        "contexts": [
            "第九条 票房分成：若影片票房收入超过5亿元，乙方额外获得超出部分2%的票房分成。",
            "第七条 甲方应向乙方支付报酬总额为人民币壹佰万元整。",
        ],
        "ground_truth": "票房超过5亿元时，乙方获得超出部分2%的分成。",
    },
    {
        "question": "违约金比例是多少？",
        "answer": "根据合同第十三条，违约金为合同总额的20%。",
        "contexts": [
            "第十三条 任何一方违反本合同约定的，应向守约方支付违约金，违约金为合同总额的20%。",
        ],
        "ground_truth": "违约金为合同总额的20%。",
    },
    {
        "question": "付款方式是怎样的？",
        "answer": "根据合同第八条，付款方式分三期：签约时支付30%，开机时支付40%，杀青时支付30%。",
        "contexts": [
            "第八条 付款方式分三期：签约时支付30%，开机时支付40%，杀青时支付30%。",
        ],
        "ground_truth": "分三期支付：签约30%、开机40%、杀青30%。",
    },
]


def run_eval():
    """运行评估"""
    setup_logging(log_level="INFO")

    print("=" * 60)
    print("影律通 RAGAS 评估")
    print("=" * 60)

    evaluator = RAGASEvaluator()
    summary = evaluator.evaluate_batch(SAMPLE_EVALUATION_DATA)

    # 生成报告
    report_gen = ReportGenerator()
    report = report_gen.generate_markdown(summary)
    print(report)

    # 保存报告
    output_dir = Path(__file__).parent.parent / "reports"
    output_dir.mkdir(exist_ok=True)
    report_path = output_dir / "evaluation_report.md"
    report_gen.generate_markdown(summary, output_path=str(report_path))
    print(f"\n✅ 报告已保存: {report_path}")


if __name__ == "__main__":
    run_eval()
