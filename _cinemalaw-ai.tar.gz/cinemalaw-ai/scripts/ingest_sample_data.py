"""
灌入示例数据

演示完整的文档处理流程：解析→切片→标注→入库。
使用方法: python scripts/ingest_sample_data.py
"""

import sys
import logging
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from config.logging import setup_logging
from src.ingestion.pipeline import IngestionPipeline
from src.models.document import DocumentType

logger = logging.getLogger(__name__)


def ingest_sample():
    """灌入示例数据"""
    setup_logging(log_level="INFO")
    logger.info("=" * 60)
    logger.info("影律通 示例数据灌入")
    logger.info("=" * 60)

    # 创建管道（Mock模式）
    pipeline = IngestionPipeline(use_mock=True)

    # 模拟处理一份合同文档
    # 实际使用中，这里应该是真实文件路径
    sample_path = "/tmp/sample_contract.pdf"
    Path(sample_path).write_text("# 模拟合同文件", encoding="utf-8")

    logger.info("\n处理示例合同文档...")
    result = pipeline.process_document(
        file_path=sample_path,
        document_type=DocumentType.ACTOR_CONTRACT,
        store=False,  # 示例模式不入真实库
    )

    # 打印结果
    print(f"\n{'='*60}")
    print(f"文档处理结果")
    print(f"{'='*60}")
    print(f"状态: {result.status.value}")
    print(f"文档ID: {result.document_id}")
    print(f"文档名称: {result.document_name}")
    print(f"总切片数: {result.total_chunks}")
    print(f"总Token数: {result.total_tokens}")
    print(f"处理耗时: {result.processing_time_seconds:.2f}秒")

    if result.chunk_batch:
        print(f"\n切片详情:")
        for chunk in result.chunk_batch.chunks[:5]:
            print(f"  [{chunk.chunk_index}] {chunk.hierarchy_path}")
            print(f"      内容: {chunk.content[:80]}...")
            print(f"      分类: {chunk.category}")
            print(f"      关键词: {chunk.keywords}")
            print()

    # 打印统计
    stats = pipeline.get_stats()
    print(f"\n管道统计: {stats}")

    # 演示检索
    print(f"\n{'='*60}")
    print("演示检索功能...")
    print(f"{'='*60}")

    from src.retrieval.hybrid_search import HybridSearcher
    searcher = HybridSearcher(use_mock=True)

    query = "演员的票房分成比例是多少？"
    result = searcher.search(query, top_k=3)
    print(f"\n查询: {query}")
    print(f"检索耗时: {result.search_time_ms:.1f}ms")
    for r in result.results:
        print(f"  [{r.rank}] {r.chunk_id} | 分数: {r.rerank_score:.4f}")
        print(f"      {r.content[:80]}...")
        print()

    print("✅ 示例数据灌入演示完成")


if __name__ == "__main__":
    ingest_sample()
