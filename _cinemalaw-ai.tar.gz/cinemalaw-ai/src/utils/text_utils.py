"""文本处理工具函数"""

from __future__ import annotations

import re
from typing import List


def count_chinese_tokens(text: str) -> int:
    """估算中文文本的token数（约1.5字符/token）"""
    return max(1, int(len(text) / 1.5))


def truncate_text(text: str, max_tokens: int, token_ratio: float = 1.5) -> str:
    """按token数截断文本，优先在句子边界截断"""
    max_chars = int(max_tokens * token_ratio)
    if len(text) <= max_chars:
        return text
    truncated = text[:max_chars]
    last_period = truncated.rfind("。")
    if last_period > max_chars * 0.5:
        return truncated[:last_period + 1]
    return truncated + "..."


def clean_whitespace(text: str) -> str:
    """清理多余空白字符"""
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def extract_legal_article_numbers(text: str) -> List[str]:
    """提取文本中的法律条款编号（如'第三条'、'第十二条'）"""
    pattern = r'第[一二三四五六七八九十百\d]+条'
    return re.findall(pattern, text)


def normalize_legal_text(text: str) -> str:
    """标准化法律文本格式"""
    text = text.replace("\r\n", "\n")
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()
