"""文件操作工具函数"""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Optional


def calculate_file_hash(file_path: str, algorithm: str = "md5") -> str:
    """计算文件哈希值"""
    hasher = hashlib.new(algorithm)
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def get_file_size_mb(file_path: str) -> float:
    """获取文件大小（MB）"""
    return Path(file_path).stat().st_size / (1024 * 1024)


def ensure_directory(path: str) -> Path:
    """确保目录存在"""
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def validate_file_format(file_path: str, allowed_formats: list) -> bool:
    """验证文件格式是否被允许"""
    suffix = Path(file_path).suffix.lower().lstrip(".")
    return suffix in [f.lower() for f in allowed_formats]
