"""异步工具函数"""

from __future__ import annotations

import asyncio
import logging
from typing import Callable, Any, List, TypeVar

logger = logging.getLogger(__name__)
T = TypeVar("T")


async def run_with_timeout(coro: Any, timeout: float) -> Any:
    """带超时的异步执行"""
    return await asyncio.wait_for(coro, timeout=timeout)


async def gather_with_limit(tasks: List, max_concurrent: int = 10) -> List:
    """限制并发数的异步gather"""
    semaphore = asyncio.Semaphore(max_concurrent)

    async def _limited(task):
        async with semaphore:
            return await task

    return await asyncio.gather(*[_limited(t) for t in tasks], return_exceptions=True)


def run_async(coro: Any) -> Any:
    """在同步代码中运行异步函数"""
    try:
        loop = asyncio.get_running_loop()
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as pool:
            return pool.submit(asyncio.run, coro).result()
    except RuntimeError:
        return asyncio.run(coro)
