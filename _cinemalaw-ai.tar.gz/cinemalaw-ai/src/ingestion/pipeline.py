"""
灌入管道编排模块

编排文档解析 → 表格转换 → 层级切片 → 元数据标注 → 数据入库的完整流程。
支持批量处理和增量更新。
"""

from __future__ import annotations

import time
import logging
from typing import List, Optional, Dict, Any
from enum import Enum

from config.settings import get_settings
from src.models.document import ParsedDocument, DocumentType
from src.models.chunk import Chunk, ChunkBatch
from src.ingestion.document_parser import create_document_parser, MockDocumentParser, LayoutLMParser
from src.ingestion.table_extractor import TableExtractor
from src.ingestion.chunking import HierarchyChunker, ChunkingConfig
from src.ingestion.metadata import MetadataEnricher

logger = logging.getLogger(__name__)


class PipelineStatus(str, Enum):
    """管道处理状态"""
    PENDING = "pending"
    PARSING = "parsing"
    CHUNKING = "chunking"
    ENRICHING = "enriching"
    INDEXING = "indexing"
    COMPLETED = "completed"
    FAILED = "failed"


class PipelineResult:
    """管道执行结果"""

    def __init__(self):
        self.status: PipelineStatus = PipelineStatus.PENDING
        self.document_id: str = ""
        self.document_name: str = ""
        self.parsed_document: Optional[ParsedDocument] = None
        self.chunk_batch: Optional[ChunkBatch] = None
        self.total_chunks: int = 0
        self.total_tokens: int = 0
        self.processing_time_seconds: float = 0.0
        self.errors: List[str] = []
        self.metadata: Dict[str, Any] = {}

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "status": self.status.value,
            "document_id": self.document_id,
            "document_name": self.document_name,
            "total_chunks": self.total_chunks,
            "total_tokens": self.total_tokens,
            "processing_time_seconds": self.processing_time_seconds,
            "errors": self.errors,
            "metadata": self.metadata,
        }


class IngestionPipeline:
    """
    数据灌入管道

    编排完整的文档处理流程：
    1. 文档解析（LayoutLM/Unstructured）
    2. 表格提取与Markdown转换
    3. 层级感知切片
    4. 元数据标注
    5. 数据入库（Milvus + Elasticsearch）

    支持：
    - 单文档处理
    - 批量文档处理
    - 增量更新
    - 错误恢复
    """

    def __init__(
        self,
        use_mock: Optional[bool] = None,
        chunking_config: Optional[ChunkingConfig] = None,
    ):
        """
        初始化灌入管道。

        Args:
            use_mock: 是否使用Mock模式，None则根据配置自动判断
            chunking_config: 切片配置
        """
        self.parser = create_document_parser(use_mock=use_mock)
        self.table_extractor = TableExtractor()
        self.chunker = HierarchyChunker(config=chunking_config)
        self.metadata_enricher = MetadataEnricher()

        self._stats = {
            "documents_processed": 0,
            "chunks_generated": 0,
            "errors": 0,
        }
        logger.info("灌入管道初始化完成 (mock=%s)", isinstance(self.parser, MockDocumentParser))

    def process_document(
        self,
        file_path: str,
        document_type: DocumentType = DocumentType.OTHER,
        store: bool = False,
    ) -> PipelineResult:
        """
        处理单个文档的完整流程。

        Args:
            file_path: 文档文件路径
            document_type: 文档类型
            store: 是否入库（Milvus + ES），默认False仅处理不入

        Returns:
            管道执行结果
        """
        result = PipelineResult()
        start_time = time.time()

        try:
            # 步骤1：文档解析
            logger.info("[步骤1/4] 解析文档: %s", file_path)
            result.status = PipelineStatus.PARSING
            parsed_doc = self.parser.parse(file_path, document_type)
            result.parsed_document = parsed_doc
            result.document_id = parsed_doc.document_id
            result.document_name = parsed_doc.metadata.document_name

            if parsed_doc.parse_status == "failed":
                result.status = PipelineStatus.FAILED
                result.errors.extend(parsed_doc.parse_errors)
                return result

            # 步骤2：表格提取与转换
            logger.info("[步骤2/4] 提取并转换表格")
            table_elements = self.table_extractor.extract_tables(parsed_doc.elements)
            # 将转换后的表格更新回文档
            for elem in parsed_doc.elements:
                if elem.element_type == "table":
                    for converted in table_elements:
                        if converted.element_id == elem.element_id:
                            elem.content = converted.content

            # 重新生成纯文本
            parsed_doc.plain_text = "\n".join(
                e.content for e in parsed_doc.elements
                if e.element_type not in ("image",)
            )

            # 步骤3：层级切片
            logger.info("[步骤3/4] 层级切片")
            result.status = PipelineStatus.CHUNKING
            chunk_batch = self.chunker.chunk_document(
                text=parsed_doc.plain_text,
                document_id=parsed_doc.document_id,
                document_name=parsed_doc.metadata.document_name,
            )

            # 步骤4：元数据标注
            logger.info("[步骤4/4] 元数据标注")
            result.status = PipelineStatus.ENRICHING
            self.metadata_enricher.enrich_chunks(
                chunks=chunk_batch.chunks,
                document_name=parsed_doc.metadata.document_name,
                document_type=document_type,
            )

            result.chunk_batch = chunk_batch
            result.total_chunks = chunk_batch.total_chunks
            result.total_tokens = chunk_batch.total_tokens

            # 步骤5（可选）：数据入库
            if store:
                result.status = PipelineStatus.INDEXING
                self._store_chunks(chunk_batch)

            result.status = PipelineStatus.COMPLETED
            result.processing_time_seconds = time.time() - start_time

            self._stats["documents_processed"] += 1
            self._stats["chunks_generated"] += result.total_chunks

            logger.info(
                "文档处理完成: %s → %d chunks, %d tokens, %.2fs",
                file_path, result.total_chunks, result.total_tokens,
                result.processing_time_seconds,
            )

        except Exception as e:
            logger.error("文档处理失败 [%s]: %s", file_path, e, exc_info=True)
            result.status = PipelineStatus.FAILED
            result.errors.append(str(e))
            result.processing_time_seconds = time.time() - start_time
            self._stats["errors"] += 1

        return result

    def process_batch(
        self,
        file_paths: List[str],
        document_type: DocumentType = DocumentType.OTHER,
        store: bool = False,
    ) -> List[PipelineResult]:
        """
        批量处理文档。

        Args:
            file_paths: 文档文件路径列表
            document_type: 统一的文档类型
            store: 是否入库

        Returns:
            每份文档的处理结果列表
        """
        logger.info("开始批量处理 %d 份文档", len(file_paths))
        results = []

        for i, file_path in enumerate(file_paths, 1):
            logger.info("处理第 %d/%d 份文档: %s", i, len(file_paths), file_path)
            result = self.process_document(file_path, document_type, store)
            results.append(result)

        success_count = sum(1 for r in results if r.status == PipelineStatus.COMPLETED)
        logger.info(
            "批量处理完成: %d/%d 成功",
            success_count, len(results),
        )
        return results

    def incremental_update(
        self,
        file_path: str,
        document_id: str,
        document_type: DocumentType = DocumentType.OTHER,
    ) -> PipelineResult:
        """
        增量更新：重新处理文档并更新索引。

        与全量重建不同，增量更新会：
        1. 检查文档是否已存在（通过document_id）
        2. 比较内容哈希，判断是否需要重新处理
        3. 仅更新变更部分

        Args:
            file_path: 文档文件路径
            document_id: 已有的文档ID
            document_type: 文档类型

        Returns:
            管道执行结果
        """
        logger.info("增量更新文档: %s (id=%s)", file_path, document_id)

        # 重新处理文档
        result = self.process_document(file_path, document_type, store=False)

        # 更新chunk的document_id为已有ID（保持一致性）
        if result.chunk_batch:
            for chunk in result.chunk_batch.chunks:
                chunk.document_id = document_id
            result.document_id = document_id

        return result

    def _store_chunks(self, chunk_batch: ChunkBatch) -> None:
        """
        将chunks写入向量数据库和BM25索引。

        此方法为框架实现，实际部署时需要根据配置连接Milvus和ES。

        Args:
            chunk_batch: 待入库的chunk批次
        """
        settings = get_settings()
        logger.info(
            "数据入库: %d chunks → Milvus(%s) + ES(%s)",
            chunk_batch.total_chunks,
            settings.milvus_uri,
            settings.es_url,
        )

        # Milvus向量入库（框架代码）
        try:
            self._store_to_milvus(chunk_batch)
        except Exception as e:
            logger.error("Milvus入库失败: %s", e)
            raise

        # Elasticsearch BM25入库（框架代码）
        try:
            self._store_to_elasticsearch(chunk_batch)
        except Exception as e:
            logger.error("Elasticsearch入库失败: %s", e)
            raise

    def _store_to_milvus(self, chunk_batch: ChunkBatch) -> None:
        """写入Milvus向量数据库"""
        # 框架实现：实际部署时需要连接Milvus并生成向量
        logger.info(
            "[Milvus] 写入 %d 条向量数据到集合: %s",
            chunk_batch.total_chunks,
            get_settings().milvus_collection,
        )
        # 实际实现步骤：
        # 1. 使用BGE-M3对每个chunk.content生成embedding
        # 2. 构建Milvus插入数据 (id, vector, metadata)
        # 3. 批量插入

    def _store_to_elasticsearch(self, chunk_batch: ChunkBatch) -> None:
        """写入Elasticsearch BM25索引"""
        logger.info(
            "[ES] 写入 %d 条文档到索引: %s",
            chunk_batch.total_chunks,
            f"{get_settings().es_index_prefix}_chunks",
        )
        # 实际实现步骤：
        # 1. 构建ES bulk请求
        # 2. 每个chunk作为一个doc，包含content + metadata
        # 3. 执行bulk写入

    def get_stats(self) -> Dict[str, Any]:
        """获取管道统计信息"""
        return {
            **self._stats,
            "table_extractor": self.table_extractor.get_stats(),
            "metadata_enricher": self.metadata_enricher.get_stats(),
        }
