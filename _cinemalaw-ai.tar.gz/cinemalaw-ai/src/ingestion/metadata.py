"""
元数据标注模块

为每个Chunk生成标准化元数据，支持文档类型自动识别和分类标注。
"""

from __future__ import annotations

import re
import logging
from datetime import datetime
from typing import List, Optional, Dict, Any

from src.models.chunk import Chunk
from src.models.document import DocumentType

logger = logging.getLogger(__name__)


# 合同类型关键词映射
DOCUMENT_TYPE_KEYWORDS: Dict[DocumentType, List[str]] = {
    DocumentType.ACTOR_CONTRACT: [
        "演员", "经纪", "艺人", "表演", "角色", "出演", "片酬",
        "演艺", "肖像权", "替身", "排练",
    ],
    DocumentType.COPYRIGHT_LICENSE: [
        "版权", "著作权", "授权", "许可", "知识产权", "IP授权",
        "改编权", "信息网络传播权", "复制权", "发行权",
    ],
    DocumentType.CO_INVESTMENT: [
        "联合投资", "联合出品", "联合制作", "投资", "出资",
        "分红", "收益分配", "投资比例",
    ],
    DocumentType.DISTRIBUTION: [
        "发行", "院线", "放映", "排片", "票房", "分账",
        "发行权", "宣传发行", "地区发行",
    ],
    DocumentType.WRITER_COMMISSION: [
        "编剧", "剧本", "创作", "委托", "撰稿", "脚本",
        "故事大纲", "文学剧本",
    ],
}

# 条款分类关键词
CATEGORY_KEYWORDS: Dict[str, List[str]] = {
    "报酬与支付": ["报酬", "片酬", "费用", "支付", "付款", "分成", "分账", "结算", "佣金"],
    "知识产权": ["著作权", "版权", "知识产权", "IP", "改编", "原创", "署名"],
    "违约责任": ["违约", "赔偿", "违约金", "解除", "终止", "免责"],
    "工作期限": ["期限", "工期", "拍摄", "档期", "时间", "日期", "工作日"],
    "保密条款": ["保密", "秘密", "泄露", "不公开", "机密"],
    "争议解决": ["争议", "仲裁", "诉讼", "管辖", "法院"],
    "权利义务": ["权利", "义务", "应", "须", "不得", "应当"],
    "保证承诺": ["保证", "承诺", "声明", "确保", "担保"],
}


class MetadataEnricher:
    """
    元数据标注器

    为每个Chunk自动标注丰富的元数据信息：
    - 文档类型自动识别
    - 条款分类标注
    - 关键词提取
    - 层级路径标准化
    """

    def __init__(self):
        """初始化元数据标注器"""
        self._stats = {"total_processed": 0, "types_detected": {}, "categories_assigned": 0}
        logger.info("元数据标注器初始化完成")

    def enrich_chunks(
        self,
        chunks: List[Chunk],
        document_name: str = "",
        document_type: Optional[DocumentType] = None,
    ) -> List[Chunk]:
        """
        批量标注Chunk元数据。

        Args:
            chunks: 待标注的Chunk列表
            document_name: 文档名称
            document_type: 已知的文档类型（可选，不传则自动检测）

        Returns:
            标注后的Chunk列表
        """
        if not chunks:
            return chunks

        # 检测文档类型
        if document_type is None:
            full_text = " ".join(c.content[:200] for c in chunks[:10])
            document_type = self._detect_document_type(full_text, document_name)

        logger.info(
            "开始标注 %d 个chunks，文档类型: %s",
            len(chunks), document_type.value if document_type else "unknown",
        )

        for chunk in chunks:
            self._enrich_single_chunk(chunk, document_name, document_type)
            self._stats["total_processed"] += 1

        logger.info("元数据标注完成")
        return chunks

    def _enrich_single_chunk(
        self,
        chunk: Chunk,
        document_name: str,
        document_type: Optional[DocumentType],
    ) -> None:
        """
        标注单个Chunk的元数据。

        Args:
            chunk: 待标注的Chunk
            document_name: 文档名称
            document_type: 文档类型
        """
        # 设置文档信息
        chunk.document_name = document_name

        # 分类标注
        category = self._classify_chunk(chunk.content)
        chunk.category = category
        if category:
            self._stats["categories_assigned"] += 1

        # 关键词提取
        chunk.keywords = self._extract_keywords(chunk.content)

        # 时间戳
        chunk.timestamp = datetime.utcnow()

        # 扩展元数据
        chunk.extra = {
            "document_type": document_type.value if document_type else "unknown",
            "enriched_at": datetime.utcnow().isoformat(),
            "content_length": len(chunk.content),
        }

    def _detect_document_type(
        self,
        text: str,
        document_name: str = "",
    ) -> DocumentType:
        """
        自动检测文档类型。

        基于关键词匹配和文件名进行综合判断。

        Args:
            text: 文档前N个chunk的文本
            document_name: 文件名

        Returns:
            检测到的文档类型
        """
        combined = f"{document_name} {text}"
        scores: Dict[DocumentType, int] = {}

        for doc_type, keywords in DOCUMENT_TYPE_KEYWORDS.items():
            score = sum(1 for kw in keywords if kw in combined)
            scores[doc_type] = score

        if not scores or max(scores.values()) == 0:
            logger.debug("未能检测到文档类型，默认为OTHER")
            return DocumentType.OTHER

        best_type = max(scores, key=scores.get)  # type: ignore
        confidence = scores[best_type]
        logger.info("文档类型检测: %s (置信度关键词数: %d)", best_type.value, confidence)

        self._stats["types_detected"][best_type.value] = (
            self._stats["types_detected"].get(best_type.value, 0) + 1
        )
        return best_type

    def _classify_chunk(self, content: str) -> str:
        """
        对Chunk进行条款分类。

        基于关键词匹配确定Chunk属于哪类条款。

        Args:
            content: Chunk文本内容

        Returns:
            分类名称，无法分类时返回空字符串
        """
        scores: Dict[str, int] = {}

        for category, keywords in CATEGORY_KEYWORDS.items():
            score = sum(1 for kw in keywords if kw in content)
            if score > 0:
                scores[category] = score

        if not scores:
            return ""

        best_category = max(scores, key=scores.get)  # type: ignore
        return best_category

    def _extract_keywords(self, content: str, max_keywords: int = 5) -> List[str]:
        """
        从Chunk中提取关键词。

        使用简单的法律术语词典匹配 + 高频名词提取。

        Args:
            content: Chunk文本内容
            max_keywords: 最大关键词数

        Returns:
            关键词列表
        """
        keywords: List[str] = []

        # 法律专业术语词典
        legal_terms = [
            "违约金", "赔偿金", "不可抗力", "知识产权", "著作权",
            "保密义务", "竞业禁止", "独家授权", "非独家", "分成比例",
            "票房分账", "署名权", "改编权", "发行权", "信息网络传播权",
            "经纪合同", "联合投资", "院线发行", "拍摄许可",
            "合同解除", "争议解决", "仲裁条款", "管辖法院",
            "预付款", "尾款", "保证金", "税费承担",
        ]

        for term in legal_terms:
            if term in content:
                keywords.append(term)
                if len(keywords) >= max_keywords:
                    break

        return keywords

    def get_stats(self) -> Dict[str, Any]:
        """获取标注统计信息"""
        return dict(self._stats)
