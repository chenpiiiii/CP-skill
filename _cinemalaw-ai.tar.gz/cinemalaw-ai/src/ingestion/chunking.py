"""
层级切片算法模块

核心模块：按照法律文档的层级结构（编-章-节-条-款-项）进行智能切片。
支持正则匹配法律层级标志，处理超长条款的次级切片和过短条款的合并。

技术参数：
- 目标chunk_size: 600 tokens
- 重叠 overlap: 120 tokens
- 支持法律层级: 编 > 章 > 节 > 条 > 款 > 项
"""

from __future__ import annotations

import re
import logging
from typing import List, Optional, Tuple, Dict, Generator
from dataclasses import dataclass, field

from config.settings import get_settings
from src.models.chunk import Chunk, ChunkBatch

logger = logging.getLogger(__name__)


# ============================================================
# 法律层级正则模式定义
# ============================================================

# 中文数字映射
_CN_NUM_MAP = {
    "一": 1, "二": 2, "三": 3, "四": 4, "五": 5,
    "六": 6, "七": 7, "八": 8, "九": 9, "十": 10,
    "十一": 11, "十二": 12, "十三": 13, "十四": 14, "十五": 15,
    "十六": 16, "十七": 17, "十八": 18, "十九": 19, "二十": 20,
    "百": 100,
}

# 层级正则模式（按优先级排列）
HIERARCHY_PATTERNS = {
    # 第X编
    "part": re.compile(r"^第([一二三四五六七八九十百]+)编\s*(.*)"),
    # 第X章
    "chapter": re.compile(r"^第([一二三四五六七八九十百]+)章\s*(.*)"),
    # X.X 节号（如 3.2节 或 第一节）
    "section": re.compile(r"^(?:(\d+(?:\.\d+)*)\s*节|第([一二三四五六七八九十]+)节)\s*(.*)"),
    # 第X条
    "article": re.compile(r"^第([一二三四五六七八九十百\d]+)条\s*(.*)"),
    # X.X.X 数字层级（如 3.2.1）
    "numbered": re.compile(r"^(\d+(?:\.\d+)+)\s*(.*)"),
    # 括号序号：(一)(二) 或 （一）（二）
    "paren_item": re.compile(r"^[（\(]([一二三四五六七八九十]+)[）\)]\s*(.*)"),
    # 数字+点序号：1. 2. 3.
    "digit_item": re.compile(r"^(\d+)\s*[.、．]\s*(.*)"),
}

# 层级深度映射
HIERARCHY_LEVELS = {
    "part": 0,
    "chapter": 1,
    "section": 2,
    "article": 3,
    "numbered": 3,  # 数字层级等同于条
    "paren_item": 4,  # 括号项等同于款
    "digit_item": 5,  # 数字项
}


@dataclass
class TextSegment:
    """文本片段，包含层级信息"""
    text: str
    level: int = 5  # 默认最低层级
    level_type: str = "text"  # 层级类型
    title: str = ""  # 层级标题
    hierarchy_path: str = ""  # 完整层级路径
    page_hint: int = 0  # 页码提示


@dataclass
class ChunkingConfig:
    """切片配置"""
    chunk_size_tokens: int = 600
    chunk_overlap_tokens: int = 120
    min_chunk_size_tokens: int = 50  # 最小切片大小（低于此值则合并）
    max_chunk_size_tokens: int = 900  # 最大切片大小（超过则强制切分）
    estimate_token_ratio: float = 1.5  # 中文字符到token的估算比例


class HierarchyChunker:
    """
    层级感知切片器

    按照法律文档的层级结构进行智能切片，确保：
    1. 切片边界与法律层级对齐（不在条款中间切断）
    2. 每个切片携带完整的层级路径信息
    3. 超长条款自动次级切片
    4. 过短条款与相邻条款合并
    5. 相邻切片之间有适当的token重叠
    """

    def __init__(self, config: Optional[ChunkingConfig] = None):
        """
        初始化切片器。

        Args:
            config: 切片配置，不传则使用全局配置
        """
        if config is None:
            settings = get_settings()
            config = ChunkingConfig(
                chunk_size_tokens=settings.chunk_size_tokens,
                chunk_overlap_tokens=settings.chunk_overlap_tokens,
            )
        self.config = config
        logger.info(
            "层级切片器初始化: chunk_size=%d, overlap=%d",
            config.chunk_size_tokens, config.chunk_overlap_tokens,
        )

    def chunk_document(
        self,
        text: str,
        document_id: str,
        document_name: str = "",
    ) -> ChunkBatch:
        """
        对完整文档进行层级切片。

        Args:
            text: 文档全文文本
            document_id: 文档ID
            document_name: 文档名称

        Returns:
            切片批次结果
        """
        import time
        start_time = time.time()

        # 第一步：识别层级结构，分段
        segments = self._identify_hierarchy(text)
        logger.info("文档层级识别完成，共 %d 个段落", len(segments))

        # 第二步：构建层级路径
        segments = self._build_hierarchy_paths(segments)

        # 第三步：合并过短段落
        segments = self._merge_short_segments(segments)
        logger.info("合并短段落后，共 %d 个段落", len(segments))

        # 第四步：切分为chunks（处理超长段落）
        chunks = self._split_into_chunks(segments, document_id, document_name)
        logger.info("切片完成，共生成 %d 个chunks", len(chunks))

        # 第五步：添加重叠
        chunks = self._add_overlap(chunks)

        batch = ChunkBatch(
            document_id=document_id,
            chunks=chunks,
        )
        batch.calculate_stats()
        batch.processing_time_seconds = time.time() - start_time

        return batch

    def _identify_hierarchy(self, text: str) -> List[TextSegment]:
        """
        识别文本中的层级结构。

        逐行扫描文本，通过正则匹配识别各层级标题，
        将文本分割为带有层级信息的段落。

        Args:
            text: 原始文档文本

        Returns:
            带层级信息的文本段落列表
        """
        lines = text.split("\n")
        segments: List[TextSegment] = []
        current_segment_lines: List[str] = []
        current_level = 5  # 默认最低层级
        current_level_type = "text"
        current_title = ""

        for line in lines:
            stripped = line.strip()
            if not stripped:
                if current_segment_lines:
                    current_segment_lines.append("")
                continue

            # 尝试匹配各种层级模式
            matched = False
            for level_type, pattern in HIERARCHY_PATTERNS.items():
                match = pattern.match(stripped)
                if match:
                    # 保存前一个段落
                    if current_segment_lines:
                        seg_text = "\n".join(current_segment_lines).strip()
                        if seg_text:
                            segments.append(TextSegment(
                                text=seg_text,
                                level=current_level,
                                level_type=current_level_type,
                                title=current_title,
                            ))

                    # 开始新段落
                    current_segment_lines = [stripped]
                    current_level = HIERARCHY_LEVELS[level_type]
                    current_level_type = level_type
                    current_title = stripped
                    matched = True
                    break

            if not matched:
                current_segment_lines.append(stripped)

        # 保存最后一个段落
        if current_segment_lines:
            seg_text = "\n".join(current_segment_lines).strip()
            if seg_text:
                segments.append(TextSegment(
                    text=seg_text,
                    level=current_level,
                    level_type=current_level_type,
                    title=current_title,
                ))

        return segments

    def _build_hierarchy_paths(self, segments: List[TextSegment]) -> List[TextSegment]:
        """
        构建每个段层的完整层级路径。

        维护一个层级栈，遇到更高层级的标题时更新栈，
        每个段落的路径由栈中所有元素拼接而成。

        Args:
            segments: 原始段落列表

        Returns:
            带完整层级路径的段落列表
        """
        # 层级栈：每层保存当前标题
        stack: Dict[int, str] = {}

        for seg in segments:
            # 更新层级栈
            stack[seg.level] = seg.title or seg.text[:30]
            # 清除更深层级
            keys_to_remove = [k for k in stack if k > seg.level]
            for k in keys_to_remove:
                del stack[k]

            # 构建路径
            path_parts = []
            for level in sorted(stack.keys()):
                path_parts.append(stack[level])
            seg.hierarchy_path = " / ".join(path_parts)

        return segments

    def _merge_short_segments(self, segments: List[TextSegment]) -> List[TextSegment]:
        """
        合并过短的段落。

        当一个段落的token数低于min_chunk_size_tokens时，
        将其与下一个同层级或更高层级的段落合并。

        Args:
            segments: 段落列表

        Returns:
            合并后的段落列表
        """
        if not segments:
            return segments

        min_tokens = self.config.min_chunk_size_tokens
        ratio = self.config.estimate_token_ratio

        merged: List[TextSegment] = []
        buffer: Optional[TextSegment] = None

        for seg in segments:
            estimated_tokens = len(seg.text) / ratio

            if buffer is None:
                buffer = seg
                continue

            buffer_tokens = len(buffer.text) / ratio

            # 如果buffer太短，尝试合并
            if buffer_tokens < min_tokens:
                # 合并文本，保留较低层级
                new_level = min(buffer.level, seg.level)
                combined_text = buffer.text + "\n\n" + seg.text
                buffer = TextSegment(
                    text=combined_text,
                    level=new_level,
                    level_type=buffer.level_type,
                    title=buffer.title,
                    hierarchy_path=seg.hierarchy_path,  # 使用更完整的路径
                )
            else:
                merged.append(buffer)
                buffer = seg

        if buffer is not None:
            merged.append(buffer)

        return merged

    def _split_into_chunks(
        self,
        segments: List[TextSegment],
        document_id: str,
        document_name: str,
    ) -> List[Chunk]:
        """
        将段落切分为最终chunks。

        对于不超过chunk_size的段落，直接作为一个chunk。
        对于超长段落，按句子边界进行次级切分。

        Args:
            segments: 段落列表
            document_id: 文档ID
            document_name: 文档名称

        Returns:
            Chunk列表
        """
        chunks: List[Chunk] = []
        chunk_index = 0
        ratio = self.config.estimate_token_ratio
        max_chars = int(self.config.max_chunk_size_tokens * ratio)

        for seg in segments:
            estimated_tokens = len(seg.text) / ratio

            if estimated_tokens <= self.config.chunk_size_tokens:
                # 整个段落作为一个chunk
                chunk = Chunk(
                    document_id=document_id,
                    document_name=document_name,
                    content=seg.text,
                    chunk_index=chunk_index,
                    token_count=int(estimated_tokens),
                    hierarchy_path=seg.hierarchy_path,
                    hierarchy_level=seg.level,
                )
                chunks.append(chunk)
                chunk_index += 1
            else:
                # 超长段落需要次级切分
                sub_chunks = self._split_long_segment(seg, document_id, document_name, chunk_index)
                chunks.extend(sub_chunks)
                chunk_index += len(sub_chunks)

        return chunks

    def _split_long_segment(
        self,
        segment: TextSegment,
        document_id: str,
        document_name: str,
        start_index: int,
    ) -> List[Chunk]:
        """
        对超长段落进行次级切分。

        切分策略：
        1. 优先按句号/分号等标点切分
        2. 保持语义完整性，不在词中间切断
        3. 次级切片之间保持适当重叠

        Args:
            segment: 超长段落
            document_id: 文档ID
            document_name: 文档名称
            start_index: 起始chunk编号

        Returns:
            次级切片列表
        """
        text = segment.text
        ratio = self.config.estimate_token_ratio
        target_chars = int(self.config.chunk_size_tokens * ratio)
        overlap_chars = int(self.config.chunk_overlap_tokens * ratio)

        # 按句子边界切分（中文句号、分号、换行符）
        sentences = re.split(r'(?<=[。；\n])', text)
        sentences = [s for s in sentences if s.strip()]

        chunks: List[Chunk] = []
        current_text = ""
        chunk_idx = start_index

        for sentence in sentences:
            # 如果加上这句会超限
            if len(current_text) + len(sentence) > target_chars and current_text:
                chunk = Chunk(
                    document_id=document_id,
                    document_name=document_name,
                    content=current_text.strip(),
                    chunk_index=chunk_idx,
                    token_count=int(len(current_text) / ratio),
                    hierarchy_path=segment.hierarchy_path + " [续]",
                    hierarchy_level=segment.level,
                )
                chunks.append(chunk)
                chunk_idx += 1

                # 保留重叠部分
                if overlap_chars > 0 and len(current_text) > overlap_chars:
                    current_text = current_text[-overlap_chars:] + sentence
                else:
                    current_text = sentence
            else:
                current_text += sentence

        # 最后剩余部分
        if current_text.strip():
            chunk = Chunk(
                document_id=document_id,
                document_name=document_name,
                content=current_text.strip(),
                chunk_index=chunk_idx,
                token_count=int(len(current_text) / ratio),
                hierarchy_path=segment.hierarchy_path + " [续]" if chunks else segment.hierarchy_path,
                hierarchy_level=segment.level,
            )
            chunks.append(chunk)

        return chunks

    def _add_overlap(self, chunks: List[Chunk]) -> List[Chunk]:
        """
        为相邻chunks添加重叠内容。

        在前一个chunk的末尾提取一部分内容，
        追加到下一个chunk的开头，确保语义连续性。

        Args:
            chunks: 原始chunk列表

        Returns:
            添加重叠后的chunk列表
        """
        if len(chunks) <= 1:
            return chunks

        ratio = self.config.estimate_token_ratio
        overlap_chars = int(self.config.chunk_overlap_tokens * ratio)

        for i in range(1, len(chunks)):
            prev_text = chunks[i - 1].content
            if len(prev_text) > overlap_chars:
                overlap_text = prev_text[-overlap_chars:]
                # 避免重复添加（如果当前chunk已经包含该重叠内容）
                if not chunks[i].content.startswith(overlap_text[:20]):
                    chunks[i].content = overlap_text + "\n" + chunks[i].content
                    chunks[i].token_count = int(len(chunks[i].content) / ratio)

        return chunks

    def estimate_tokens(self, text: str) -> int:
        """
        估算文本的token数量。

        使用简单的字符比例估算，中文约1.5字符/token。
        生产环境建议替换为tiktoken精确计算。

        Args:
            text: 待估算的文本

        Returns:
            估算的token数
        """
        return int(len(text) / self.config.estimate_token_ratio)

    def chunk_text_generator(
        self,
        text: str,
        document_id: str,
        document_name: str = "",
    ) -> Generator[Chunk, None, None]:
        """
        流式切片生成器（用于大文档处理）。

        Args:
            text: 文档文本
            document_id: 文档ID
            document_name: 文档名称

        Yields:
            逐个产出Chunk
        """
        batch = self.chunk_document(text, document_id, document_name)
        for chunk in batch.chunks:
            yield chunk
