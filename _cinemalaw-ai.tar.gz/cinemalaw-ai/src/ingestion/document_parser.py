"""
文档解析模块

集成 LayoutLM v3 进行版面分析，支持PDF、图片、DOCX的解析。
提供 Mock 实现（开发/测试模式）和真实实现（生产模式）两种模式，通过配置切换。
"""

from __future__ import annotations

import time
import logging
from pathlib import Path
from typing import List, Optional, Protocol

from config.settings import get_settings
from src.models.document import (
    ParsedDocument, DocumentMetadata, DocumentElement,
    ElementType, BoundingBox, DocumentType,
)

logger = logging.getLogger(__name__)


class DocumentParserInterface(Protocol):
    """文档解析器接口定义"""

    def parse(self, file_path: str, document_type: DocumentType = DocumentType.OTHER) -> ParsedDocument:
        """解析文档文件"""
        ...

    async def parse_async(self, file_path: str, document_type: DocumentType = DocumentType.OTHER) -> ParsedDocument:
        """异步解析文档文件"""
        ...


class LayoutLMParser:
    """
    基于 LayoutLM v3 的文档解析器（真实实现）

    使用 LayoutLM v3 模型进行版面分析，能识别标题、正文、表格、图片、
    印章、签名等版面元素，并提取空间布局信息。

    注意：此实现需要GPU环境和预训练模型。
    """

    def __init__(self, model_path: Optional[str] = None, device: Optional[str] = None):
        """
        初始化LayoutLM解析器。

        Args:
            model_path: 模型路径，默认从配置读取
            device: 计算设备，默认从配置读取
        """
        settings = get_settings()
        self.model_path = model_path or settings.layoutlm_model_path
        self.use_gpu = settings.layoutlm_use_gpu
        self.device = device or ("cuda:0" if self.use_gpu else "cpu")
        self._model = None
        self._processor = None
        logger.info("LayoutLM解析器初始化: model=%s, device=%s", self.model_path, self.device)

    def _load_model(self) -> None:
        """延迟加载模型（首次调用时加载）"""
        if self._model is not None:
            return

        logger.info("正在加载 LayoutLM v3 模型: %s", self.model_path)
        try:
            from transformers import LayoutLMv3ForSequenceClassification, LayoutLMv3FeatureExtractor
            self._processor = LayoutLMv3FeatureExtractor.from_pretrained(self.model_path)
            self._model = LayoutLMv3ForSequenceClassification.from_pretrained(self.model_path)
            self._model.to(self.device)
            self._model.eval()
            logger.info("LayoutLM v3 模型加载完成")
        except ImportError:
            raise RuntimeError(
                "LayoutLM 依赖未安装，请运行: pip install transformers torch torchvision"
            )
        except Exception as e:
            raise RuntimeError(f"LayoutLM 模型加载失败: {e}")

    def parse(self, file_path: str, document_type: DocumentType = DocumentType.OTHER) -> ParsedDocument:
        """
        解析文档文件。

        Args:
            file_path: 文件路径
            document_type: 文档类型

        Returns:
            解析后的文档结构
        """
        start_time = time.time()
        self._load_model()

        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"文件不存在: {file_path}")

        suffix = path.suffix.lower()
        if suffix == ".pdf":
            elements = self._parse_pdf(path)
        elif suffix in (".png", ".jpg", ".jpeg", ".tiff"):
            elements = self._parse_image(path)
        elif suffix == ".docx":
            elements = self._parse_docx(path)
        else:
            raise ValueError(f"不支持的文件格式: {suffix}")

        parse_time = time.time() - start_time
        plain_text = "\n".join(e.content for e in elements if e.element_type != ElementType.IMAGE)

        metadata = DocumentMetadata(
            document_name=path.name,
            document_type=document_type,
            file_size_bytes=path.stat().st_size,
        )

        return ParsedDocument(
            metadata=metadata,
            elements=elements,
            plain_text=plain_text,
            parse_time_seconds=parse_time,
            parse_status="success",
        )

    async def parse_async(self, file_path: str, document_type: DocumentType = DocumentType.OTHER) -> ParsedDocument:
        """异步解析（当前为同步包装，未来可替换为真正的异步实现）"""
        return self.parse(file_path, document_type)

    def _parse_pdf(self, path: Path) -> List[DocumentElement]:
        """解析PDF文件"""
        logger.info("解析PDF文件: %s", path.name)
        # LayoutLM v3 处理PDF的实际实现
        # 需要: pdf2image / PyMuPDF 进行页面渲染
        try:
            from pdf2image import convert_from_path
            images = convert_from_path(str(path))
            elements = []
            for page_idx, image in enumerate(images):
                page_elements = self._analyze_page(image, page_idx)
                elements.extend(page_elements)
            return elements
        except ImportError:
            logger.warning("pdf2image未安装，使用降级方案")
            return self._fallback_parse_pdf(path)

    def _fallback_parse_pdf(self, path: Path) -> List[DocumentElement]:
        """PDF解析降级方案（使用PyPDF2纯文本提取）"""
        try:
            import PyPDF2
            elements = []
            with open(path, "rb") as f:
                reader = PyPDF2.PdfReader(f)
                for page_idx, page in enumerate(reader.pages):
                    text = page.extract_text() or ""
                    if text.strip():
                        elements.append(DocumentElement(
                            element_type=ElementType.TEXT,
                            content=text.strip(),
                            bbox=BoundingBox(x_min=0, y_min=0, x_max=1, y_max=1, page=page_idx),
                            metadata={"source": "fallback_pypdf2"},
                        ))
            return elements
        except Exception as e:
            logger.error("PDF降级解析也失败: %s", e)
            return []

    def _parse_image(self, path: Path) -> List[DocumentElement]:
        """解析图片文件"""
        logger.info("解析图片文件: %s", path.name)
        from PIL import Image
        image = Image.open(path)
        return self._analyze_page(image, 0)

    def _parse_docx(self, path: Path) -> List[DocumentElement]:
        """解析DOCX文件"""
        logger.info("解析DOCX文件: %s", path.name)
        try:
            from docx import Document
            doc = Document(str(path))
            elements = []
            for para in doc.paragraphs:
                text = para.text.strip()
                if not text:
                    continue
                # 根据样式判断是否为标题
                if para.style and "Heading" in (para.style.name or ""):
                    elements.append(DocumentElement(
                        element_type=ElementType.TITLE,
                        content=text,
                    ))
                else:
                    elements.append(DocumentElement(
                        element_type=ElementType.TEXT,
                        content=text,
                    ))
            # 处理表格
            for table in doc.tables:
                md_table = self._docx_table_to_markdown(table)
                elements.append(DocumentElement(
                    element_type=ElementType.TABLE,
                    content=md_table,
                ))
            return elements
        except ImportError:
            logger.error("python-docx未安装")
            return []

    def _analyze_page(self, image, page_idx: int) -> List[DocumentElement]:
        """使用LayoutLM分析单页图片"""
        # 实际LayoutLM推理逻辑
        # 此处为框架实现，实际部署时需要完整的推理管线
        logger.debug("分析第 %d 页", page_idx)
        return [DocumentElement(
            element_type=ElementType.TEXT,
            content="[LayoutLM推理结果占位]",
            bbox=BoundingBox(x_min=0, y_min=0, x_max=1, y_max=1, page=page_idx),
            metadata={"source": "layoutlm_v3", "page": page_idx},
        )]

    @staticmethod
    def _docx_table_to_markdown(table) -> str:
        """将DOCX表格转换为Markdown格式"""
        rows = []
        for row in table.rows:
            cells = [cell.text.strip().replace("\n", " ") for cell in row.cells]
            rows.append("| " + " | ".join(cells) + " |")
        if len(rows) >= 1:
            # 在第一行后添加分隔行
            separator = "| " + " | ".join(["---"] * len(table.rows[0].cells)) + " |"
            rows.insert(1, separator)
        return "\n".join(rows)


class MockDocumentParser:
    """
    Mock文档解析器（开发/测试模式）

    模拟LayoutLM的解析行为，生成可预测的测试数据。
    用于在无GPU环境下进行开发和测试。
    """

    # 模拟的法律合同文本片段
    MOCK_CONTRACT_TEXT = """第一章 总则
第一条 本合同由甲方（制片方）与乙方（演员）共同签订，就乙方参与甲方影视作品拍摄事宜达成一致。
第二条 本协议适用于中华人民共和国境内法律法规框架下的影视制作活动。
第三条 双方应遵循平等互利、诚实信用的原则履行本协议。

第二章 工作内容与期限
第四条 乙方同意在甲方指定的影视项目（以下简称"本项目"）中担任角色。
第五条 拍摄周期自合同签订之日起至杀青之日止，预计总时长为90个工作日。
第六条 乙方应保证在拍摄期间全身心投入本项目，未经甲方书面同意不得参与其他商业活动。

第三章 报酬与支付
第七条 甲方应向乙方支付报酬总额为人民币壹佰万元整（¥1,000,000.00）。
第八条 付款方式分三期：签约时支付30%，开机时支付40%，杀青时支付30%。
第九条 票房分成：若影片票房收入超过5亿元，乙方额外获得超出部分2%的票房分成。

第四章 知识产权
第十条 乙方在本项目中产生的表演成果，其著作权归甲方所有。
第十一条 甲方有权在全球范围内、以各种媒介形式使用乙方的表演形象。
第十二条 乙方保留其署名权，甲方应在影片片头/片尾为乙方署名。

第五章 违约责任
第十三条 任何一方违反本合同约定的，应向守约方支付违约金，违约金为合同总额的20%。
第十四条 乙方因个人原因无法完成拍摄的，应退还已收取的全部报酬，并赔偿甲方因此产生的直接损失。
第十五条 因不可抗力导致合同无法履行的，双方互不承担违约责任。
"""

    def parse(self, file_path: str, document_type: DocumentType = DocumentType.OTHER) -> ParsedDocument:
        """
        Mock解析：返回预定义的合同文本结构。

        Args:
            file_path: 文件路径（仅用于获取文件名）
            document_type: 文档类型

        Returns:
            模拟的解析结果
        """
        start_time = time.time()
        path = Path(file_path)
        logger.info("[Mock] 解析文件: %s", path.name)

        elements: List[DocumentElement] = []
        lines = self.MOCK_CONTRACT_TEXT.strip().split("\n")

        for line in lines:
            line = line.strip()
            if not line:
                continue

            if line.startswith("第") and "章" in line[:6]:
                elements.append(DocumentElement(
                    element_type=ElementType.TITLE,
                    content=line,
                    confidence=0.98,
                ))
            elif line.startswith("第") and "条" in line[:6]:
                elements.append(DocumentElement(
                    element_type=ElementType.TEXT,
                    content=line,
                    confidence=0.95,
                    metadata={"is_article": True},
                ))
            else:
                elements.append(DocumentElement(
                    element_type=ElementType.TEXT,
                    content=line,
                    confidence=0.90,
                ))

        # 添加一个模拟表格
        elements.append(DocumentElement(
            element_type=ElementType.TABLE,
            content="| 付款期次 | 支付比例 | 支付条件 |\n| --- | --- | --- |\n| 第一期 | 30% | 签约时 |\n| 第二期 | 40% | 开机时 |\n| 第三期 | 30% | 杀青时 |",
            confidence=0.92,
            metadata={"table_type": "payment_schedule"},
        ))

        parse_time = time.time() - start_time
        plain_text = "\n".join(e.content for e in elements)

        return ParsedDocument(
            metadata=DocumentMetadata(
                document_name=path.name,
                document_type=document_type,
                total_pages=5,
                file_size_bytes=1024 * 50,
            ),
            elements=elements,
            plain_text=plain_text,
            parse_time_seconds=parse_time,
            parse_status="success",
        )

    async def parse_async(self, file_path: str, document_type: DocumentType = DocumentType.OTHER) -> ParsedDocument:
        """异步Mock解析"""
        return self.parse(file_path, document_type)


def create_document_parser(use_mock: Optional[bool] = None) -> LayoutLMParser | MockDocumentParser:
    """
    工厂函数：根据配置创建合适的文档解析器。

    Args:
        use_mock: 是否使用Mock模式，None时根据配置自动判断

    Returns:
        文档解析器实例
    """
    settings = get_settings()

    if use_mock is None:
        # 开发环境默认使用Mock
        use_mock = settings.app_env in ("development", "test")
        # 如果配置了远程服务地址，也不使用Mock
        if settings.layoutlm_use_remote and settings.layoutlm_endpoint:
            use_mock = False

    if use_mock:
        logger.info("使用Mock文档解析器（开发/测试模式）")
        return MockDocumentParser()
    else:
        logger.info("使用LayoutLM v3文档解析器（生产模式）")
        return LayoutLMParser()
