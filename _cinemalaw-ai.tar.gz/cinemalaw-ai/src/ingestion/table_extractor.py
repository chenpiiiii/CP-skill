"""
表格提取与Markdown转换模块

将文档解析器检测到的表格区域转换为标准Markdown格式，
保持表格结构完整性，支持复杂表格（合并单元格、多级表头）。
"""

from __future__ import annotations

import re
import logging
from typing import List, Optional, Tuple, Dict, Any

from src.models.document import DocumentElement, ElementType

logger = logging.getLogger(__name__)


class TableExtractor:
    """
    表格提取与Markdown转换器

    将检测到的表格区域（HTML/结构化数据）转换为Markdown格式表格。
    保持表格结构完整性，处理合并单元格和多级表头等复杂场景。
    """

    def __init__(self, preserve_header: bool = True):
        """
        初始化表格提取器。

        Args:
            preserve_header: 是否保留表头行（默认True）
        """
        self.preserve_header = preserve_header
        self._stats = {"total_tables": 0, "success": 0, "failed": 0}

    def extract_tables(self, elements: List[DocumentElement]) -> List[DocumentElement]:
        """
        从文档元素列表中提取并转换所有表格。

        Args:
            elements: 文档元素列表

        Returns:
            转换后的表格元素列表（Markdown格式）
        """
        table_elements = [e for e in elements if e.element_type == ElementType.TABLE]
        results = []

        for elem in table_elements:
            self._stats["total_tables"] += 1
            try:
                md_content = self.convert_to_markdown(elem)
                results.append(DocumentElement(
                    element_id=elem.element_id,
                    element_type=ElementType.TABLE,
                    content=md_content,
                    bbox=elem.bbox,
                    confidence=elem.confidence,
                    metadata={**elem.metadata, "markdown_converted": True},
                ))
                self._stats["success"] += 1
            except Exception as e:
                logger.error("表格转换失败 [%s]: %s", elem.element_id, e)
                self._stats["failed"] += 1
                # 保留原始内容作为降级
                results.append(elem)

        return results

    def convert_to_markdown(self, element: DocumentElement) -> str:
        """
        将单个表格元素转换为Markdown格式。

        根据表格内容的格式自动选择转换策略：
        - 已经是Markdown格式 → 直接返回
        - HTML表格 → HTML解析转换
        - 结构化数据（JSON/List） → 构建Markdown
        - 纯文本 → 尝试正则解析

        Args:
            element: 表格类型的文档元素

        Returns:
            Markdown格式的表格字符串
        """
        content = element.content.strip()

        # 已经是Markdown表格格式
        if self._is_markdown_table(content):
            logger.debug("表格已是Markdown格式，直接返回")
            return self._normalize_markdown_table(content)

        # HTML表格格式
        if content.startswith("<table") or content.startswith("<TABLE"):
            logger.debug("检测到HTML表格，进行转换")
            return self._html_table_to_markdown(content)

        # JSON结构化数据
        if content.startswith("[") or content.startswith("{"):
            logger.debug("检测到JSON结构化表格数据")
            return self._json_to_markdown_table(content)

        # 尝试从纯文本解析
        logger.debug("尝试从纯文本解析表格")
        return self._text_to_markdown_table(content)

    def _is_markdown_table(self, content: str) -> bool:
        """判断内容是否已经是Markdown表格格式"""
        lines = content.strip().split("\n")
        if len(lines) < 2:
            return False
        # 检查是否包含Markdown表格标志：至少有一行以 | 开头
        pipe_lines = sum(1 for line in lines if line.strip().startswith("|"))
        return pipe_lines >= 2

    def _normalize_markdown_table(self, content: str) -> str:
        """标准化Markdown表格格式（对齐、清理）"""
        lines = content.strip().split("\n")
        normalized = []
        for line in lines:
            line = line.strip()
            if line:
                # 确保首尾有 |
                if not line.startswith("|"):
                    line = "| " + line
                if not line.endswith("|"):
                    line = line + " |"
                normalized.append(line)
        return "\n".join(normalized)

    def _html_table_to_markdown(self, html_content: str) -> str:
        """
        将HTML表格转换为Markdown格式。

        处理 <table>, <tr>, <td>, <th> 标签。
        """
        try:
            from html.parser import HTMLParser

            rows: List[List[str]] = []
            current_row: List[str] = []
            current_cell = ""
            in_cell = False

            class SimpleTableParser(HTMLParser):
                def handle_starttag(self, tag, attrs):
                    nonlocal current_cell, in_cell
                    if tag in ("td", "th"):
                        in_cell = True
                        current_cell = ""
                    elif tag == "tr":
                        current_row = []

                def handle_data(self, data):
                    nonlocal current_cell
                    if in_cell:
                        current_cell += data.strip()

                def handle_endtag(self, tag):
                    nonlocal in_cell, current_row
                    if tag in ("td", "th"):
                        in_cell = False
                        current_row.append(current_cell)
                    elif tag == "tr":
                        if current_row:
                            rows.append(current_row)
                        current_row = []

            parser = SimpleTableParser()
            parser.feed(html_content)

            if not rows:
                return html_content

            return self._rows_to_markdown(rows)

        except Exception as e:
            logger.error("HTML表格解析失败: %s", e)
            return html_content

    def _json_to_markdown_table(self, json_content: str) -> str:
        """将JSON结构化数据转换为Markdown表格"""
        import json

        try:
            data = json.loads(json_content)
            if isinstance(data, list) and len(data) > 0:
                if isinstance(data[0], dict):
                    headers = list(data[0].keys())
                    rows = [headers]
                    for item in data:
                        rows.append([str(item.get(h, "")) for h in headers])
                    return self._rows_to_markdown(rows)
                elif isinstance(data[0], list):
                    return self._rows_to_markdown(
                        [[str(cell) for cell in row] for row in data]
                    )
        except (json.JSONDecodeError, KeyError) as e:
            logger.error("JSON表格数据解析失败: %s", e)

        return json_content

    def _text_to_markdown_table(self, text_content: str) -> str:
        """
        尝试从纯文本中解析表格结构。

        检测策略：
        1. 以制表符(\t)分隔 → 转换为Markdown表格
        2. 以多个空格对齐 → 尝试列对齐解析
        3. 无法解析 → 返回原始文本
        """
        lines = text_content.strip().split("\n")
        if len(lines) < 2:
            return text_content

        # 尝试制表符分隔
        if "\t" in text_content:
            rows = [line.split("\t") for line in lines if line.strip()]
            if len(rows) >= 2:
                return self._rows_to_markdown(rows)

        # 尝试固定宽度解析（简单启发式）
        # 如果多数行有相似数量的空格分隔块
        split_rows = []
        for line in lines:
            parts = re.split(r"\s{2,}", line.strip())
            if len(parts) >= 2:
                split_rows.append(parts)

        if len(split_rows) >= 2:
            # 检查列数一致性
            col_counts = [len(r) for r in split_rows]
            if max(col_counts) - min(col_counts) <= 1:
                return self._rows_to_markdown(split_rows)

        return text_content

    def _rows_to_markdown(self, rows: List[List[str]]) -> str:
        """
        将二维数组转换为Markdown表格。

        Args:
            rows: 二维字符串数组，第一行为表头

        Returns:
            格式化的Markdown表格字符串
        """
        if not rows:
            return ""

        # 计算每列最大宽度
        num_cols = max(len(row) for row in rows)
        col_widths = [0] * num_cols
        for row in rows:
            for i, cell in enumerate(row):
                col_widths[i] = max(col_widths[i], len(str(cell)))

        # 确保每行列数一致
        normalized_rows = []
        for row in rows:
            padded = [str(cell).strip() for cell in row]
            while len(padded) < num_cols:
                padded.append("")
            normalized_rows.append(padded)

        # 构建Markdown表格
        lines = []
        # 表头
        header = normalized_rows[0]
        lines.append("| " + " | ".join(header) + " |")
        # 分隔行
        separator = "| " + " | ".join(["---"] * num_cols) + " |"
        lines.append(separator)
        # 数据行
        for row in normalized_rows[1:]:
            lines.append("| " + " | ".join(row) + " |")

        return "\n".join(lines)

    def get_stats(self) -> Dict[str, int]:
        """获取转换统计信息"""
        return dict(self._stats)

    def insert_tables_into_text(
        self,
        text_elements: List[DocumentElement],
        table_elements: List[DocumentElement],
    ) -> List[DocumentElement]:
        """
        将转换后的表格插入到文本元素序列中的正确位置。

        根据表格的bbox位置信息，将表格插入到相邻文本元素之间。

        Args:
            text_elements: 文本元素列表
            table_elements: 已转换的表格元素列表

        Returns:
            合并后的元素列表（文本与表格交替排列）
        """
        if not table_elements:
            return text_elements

        result = list(text_elements)

        for table_elem in table_elements:
            if table_elem.bbox is None:
                result.append(table_elem)
                continue

            table_page = table_elem.bbox.page
            table_y = table_elem.bbox.y_min

            # 找到表格应该插入的位置（按页码和y坐标）
            insert_idx = len(result)
            for i, elem in enumerate(result):
                if elem.bbox and elem.bbox.page == table_page:
                    if elem.bbox.y_min > table_y:
                        insert_idx = i
                        break

            result.insert(insert_idx, table_elem)

        return result
