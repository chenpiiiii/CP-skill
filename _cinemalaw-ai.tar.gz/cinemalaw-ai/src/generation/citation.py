"""
引用溯源处理模块

解析LLM输出中的引用标记（[引用N]），生成溯源高亮信息，
将回答中的每条引用精确映射到原始Chunk和文档位置。
"""

from __future__ import annotations

import re
import logging
from typing import List, Dict, Any, Optional, Tuple

from src.models.response import Citation, RAGResponse, ReviewFinding, ConfidenceLevel
from src.models.search_result import RerankResult

logger = logging.getLogger(__name__)

# 引用标记正则：匹配 [引用1]、[引用2] 等格式
CITATION_PATTERN = re.compile(r'\[引用(\d+)\]')


class CitationProcessor:
    """
    引用溯源处理器

    职责：
    1. 解析LLM输出中的 [引用N] 标记
    2. 将引用编号映射到对应的Chunk上下文
    3. 生成结构化的溯源信息
    4. 计算每条引用的相关度得分
    """

    def __init__(self):
        """初始化引用处理器"""
        self._stats = {"processed": 0, "citations_found": 0, "orphan_citations": 0}

    def process_citations(
        self,
        llm_output: str,
        contexts: List[RerankResult],
    ) -> Tuple[str, List[Citation]]:
        """
        解析LLM输出中的引用标记并生成溯源信息。

        Args:
            llm_output: LLM生成的文本
            contexts: 检索到的上下文列表（按排名顺序）

        Returns:
            (清理后的文本, 引用列表) 元组
        """
        self._stats["processed"] += 1
        citations: List[Citation] = []

        # 提取所有引用标记
        citation_matches = CITATION_PATTERN.findall(llm_output)
        unique_refs = sorted(set(int(m) for m in citation_matches))

        logger.debug("发现 %d 个唯一引用标记: %s", len(unique_refs), unique_refs)

        for ref_num in unique_refs:
            self._stats["citations_found"] += 1

            # 引用编号从1开始，对应contexts的索引从0开始
            ctx_idx = ref_num - 1
            if ctx_idx < len(contexts):
                ctx = contexts[ctx_idx]
                # 提取最相关的片段（取前200字）
                relevant_text = self._extract_relevant_text(ctx.content, max_chars=200)

                citation = Citation(
                    citation_id=ref_num,
                    chunk_id=ctx.chunk_id,
                    document_name=ctx.document_name,
                    hierarchy_path=ctx.hierarchy_path,
                    page_range=ctx.page_range,
                    relevant_text=relevant_text,
                    relevance_score=ctx.rerank_score,
                )
                citations.append(citation)
            else:
                # 引用编号超出上下文范围
                logger.warning("孤立引用: [引用%d]，上下文仅%d条", ref_num, len(contexts))
                self._stats["orphan_citations"] += 1
                citation = Citation(
                    citation_id=ref_num,
                    chunk_id="",
                    document_name="[引用缺失]",
                    hierarchy_path="",
                    relevant_text="",
                    relevance_score=0.0,
                )
                citations.append(citation)

        return llm_output, citations

    def _extract_relevant_text(self, content: str, max_chars: int = 200) -> str:
        """
        从Chunk内容中提取最相关的片段。

        当前使用简单策略：取前N个字符。
        未来可优化为基于attention或关键词的句子级提取。

        Args:
            content: Chunk完整内容
            max_chars: 最大字符数

        Returns:
            截断后的文本
        """
        if len(content) <= max_chars:
            return content

        # 尝试在句子边界截断
        truncated = content[:max_chars]
        last_period = truncated.rfind("。")
        if last_period > max_chars * 0.5:
            return truncated[:last_period + 1]

        return truncated + "..."

    def parse_review_findings(
        self,
        llm_output: str,
        contexts: List[RerankResult],
        citations: List[Citation],
    ) -> List[ReviewFinding]:
        """
        从LLM输出中解析审查发现项。

        尝试将LLM的结构化输出解析为ReviewFinding对象列表。

        Args:
            llm_output: LLM生成的文本
            contexts: 上下文列表
            citations: 已解析的引用列表

        Returns:
            审查发现项列表
        """
        findings: List[ReviewFinding] = []
        citation_map = {c.citation_id: c for c in citations}

        # 简单启发式解析：按段落分割，识别严重程度标记
        sections = re.split(r'\n\s*\n', llm_output)

        finding_idx = 0
        for section in sections:
            section = section.strip()
            if not section:
                continue

            # 检测严重程度
            severity = self._detect_severity(section)

            # 提取该段落中的引用
            section_citations = []
            for match in CITATION_PATTERN.finditer(section):
                ref_num = int(match.group(1))
                if ref_num in citation_map:
                    section_citations.append(citation_map[ref_num])

            # 如果包含引用或严重程度，认为是一个发现项
            if section_citations or severity:
                finding_idx += 1
                findings.append(ReviewFinding(
                    finding_id=f"finding_{finding_idx:03d}",
                    severity=severity,
                    category=self._detect_category(section),
                    description=self._extract_description(section),
                    citations=section_citations,
                    confidence=ConfidenceLevel.HIGH if section_citations else ConfidenceLevel.MEDIUM,
                ))

        return findings

    def _detect_severity(self, text: str) -> str:
        """检测文本中的严重程度标记"""
        text_lower = text.lower()
        if any(kw in text for kw in ["致命", "critical", "严重", "违法", "无效"]):
            return "critical"
        if any(kw in text for kw in ["高风险", "重大", "high"]):
            return "high"
        if any(kw in text for kw in ["中等", "建议", "medium", "注意"]):
            return "medium"
        if any(kw in text for kw in ["轻微", "low", "可选"]):
            return "low"
        return "info"

    def _detect_category(self, text: str) -> str:
        """检测文本涉及的条款分类"""
        if any(kw in text for kw in ["报酬", "片酬", "支付", "分成"]):
            return "报酬与支付"
        if any(kw in text for kw in ["版权", "著作权", "知识产权", "IP"]):
            return "知识产权"
        if any(kw in text for kw in ["违约", "赔偿", "解除"]):
            return "违约责任"
        if any(kw in text for kw in ["保密", "秘密"]):
            return "保密条款"
        if any(kw in text for kw in ["期限", "档期", "工期"]):
            return "工作期限"
        return "其他"

    def _extract_description(self, text: str, max_length: int = 200) -> str:
        """从段落中提取问题描述"""
        # 取第一行或前200字
        first_line = text.split("\n")[0].strip()
        if len(first_line) <= max_length:
            return first_line
        return first_line[:max_length] + "..."

    def assess_confidence(
        self,
        citations: List[Citation],
        llm_output: str,
    ) -> ConfidenceLevel:
        """
        评估回答的整体置信度。

        Args:
            citations: 引用列表
            llm_output: LLM输出文本

        Returns:
            置信度级别
        """
        if not citations:
            return ConfidenceLevel.NO_EVIDENCE

        avg_score = sum(c.relevance_score for c in citations) / len(citations)
        valid_citations = sum(1 for c in citations if c.chunk_id)

        if valid_citations >= 3 and avg_score >= 0.7:
            return ConfidenceLevel.HIGH
        elif valid_citations >= 1 and avg_score >= 0.5:
            return ConfidenceLevel.MEDIUM
        else:
            return ConfidenceLevel.LOW

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return dict(self._stats)
