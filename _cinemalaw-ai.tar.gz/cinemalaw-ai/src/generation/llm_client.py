"""
LLM调用封装模块

封装 Claude / DeepSeek API调用，支持流式输出和错误重试机制。
"""

from __future__ import annotations

import time
import logging
import asyncio
from typing import Dict, Any, Optional, AsyncGenerator, List

from config.settings import get_settings

logger = logging.getLogger(__name__)


class LLMClient:
    """
    LLM调用客户端

    封装多个LLM提供商的API调用，提供统一接口：
    - Claude 3.5 Sonnet（主力模型）
    - DeepSeek-R1/V3（备选/降级模型）

    支持：
    - 同步/异步调用
    - 流式输出
    - 错误重试（指数退避）
    - 超时控制
    """

    def __init__(
        self,
        provider: Optional[str] = None,
        max_retries: int = 3,
        timeout: float = 30.0,
    ):
        """
        初始化LLM客户端。

        Args:
            provider: LLM提供商，不传则使用配置
            max_retries: 最大重试次数
            timeout: 请求超时时间（秒）
        """
        settings = get_settings()
        self.provider = provider or settings.llm_provider
        self.max_retries = max_retries
        self.timeout = timeout
        self._stats = {"total_calls": 0, "retries": 0, "errors": 0}
        logger.info("LLM客户端初始化: provider=%s, max_retries=%d", self.provider, max_retries)

    async def generate(
        self,
        system_prompt: str,
        user_message: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
    ) -> Dict[str, Any]:
        """
        生成LLM回复（非流式）。

        Args:
            system_prompt: 系统提示词
            user_message: 用户消息
            temperature: 温度参数
            max_tokens: 最大输出token数
            stream: 是否使用流式

        Returns:
            包含content、usage等信息的字典
        """
        self._stats["total_calls"] += 1

        if self.provider == "claude":
            return await self._call_claude(system_prompt, user_message, temperature, max_tokens)
        elif self.provider == "deepseek":
            return await self._call_deepseek(system_prompt, user_message, temperature, max_tokens)
        else:
            return await self._call_mock(system_prompt, user_message)

    async def generate_stream(
        self,
        system_prompt: str,
        user_message: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> AsyncGenerator[str, None]:
        """
        流式生成LLM回复。

        Args:
            system_prompt: 系统提示词
            user_message: 用户消息
            temperature: 温度参数
            max_tokens: 最大输出token数

        Yields:
            逐块文本内容
        """
        self._stats["total_calls"] += 1

        if self.provider == "claude":
            async for chunk in self._stream_claude(system_prompt, user_message, temperature, max_tokens):
                yield chunk
        elif self.provider == "deepseek":
            async for chunk in self._stream_deepseek(system_prompt, user_message, temperature, max_tokens):
                yield chunk
        else:
            async for chunk in self._stream_mock(system_prompt, user_message):
                yield chunk

    async def _call_claude(
        self,
        system_prompt: str,
        user_message: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:
        """调用Claude API"""
        settings = get_settings()
        temp = temperature if temperature is not None else settings.claude_temperature
        tokens = max_tokens or settings.claude_max_tokens

        for attempt in range(self.max_retries):
            try:
                import httpx
                async with httpx.AsyncClient(timeout=self.timeout) as client:
                    response = await client.post(
                        "https://api.anthropic.com/v1/messages",
                        headers={
                            "x-api-key": settings.claude_api_key,
                            "anthropic-version": "2023-06-01",
                            "content-type": "application/json",
                        },
                        json={
                            "model": settings.claude_model,
                            "max_tokens": tokens,
                            "temperature": temp,
                            "system": system_prompt,
                            "messages": [{"role": "user", "content": user_message}],
                        },
                    )
                    response.raise_for_status()
                    data = response.json()

                    return {
                        "content": data["content"][0]["text"],
                        "model": data["model"],
                        "usage": {
                            "input_tokens": data.get("usage", {}).get("input_tokens", 0),
                            "output_tokens": data.get("usage", {}).get("output_tokens", 0),
                        },
                        "stop_reason": data.get("stop_reason", "end_turn"),
                    }

            except Exception as e:
                self._stats["retries"] += 1
                logger.warning("Claude API调用失败 (第%d次): %s", attempt + 1, e)
                if attempt < self.max_retries - 1:
                    wait_time = 2 ** attempt  # 指数退避
                    await asyncio.sleep(wait_time)
                else:
                    self._stats["errors"] += 1
                    raise

        return {}  # 不应到达这里

    async def _call_deepseek(
        self,
        system_prompt: str,
        user_message: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:
        """调用DeepSeek API（OpenAI兼容接口）"""
        settings = get_settings()
        temp = temperature if temperature is not None else settings.deepseek_temperature
        tokens = max_tokens or settings.deepseek_max_tokens

        for attempt in range(self.max_retries):
            try:
                import httpx
                async with httpx.AsyncClient(timeout=self.timeout) as client:
                    response = await client.post(
                        f"{settings.deepseek_base_url}/chat/completions",
                        headers={
                            "Authorization": f"Bearer {settings.deepseek_api_key}",
                            "Content-Type": "application/json",
                        },
                        json={
                            "model": settings.deepseek_model,
                            "max_tokens": tokens,
                            "temperature": temp,
                            "messages": [
                                {"role": "system", "content": system_prompt},
                                {"role": "user", "content": user_message},
                            ],
                        },
                    )
                    response.raise_for_status()
                    data = response.json()

                    return {
                        "content": data["choices"][0]["message"]["content"],
                        "model": data["model"],
                        "usage": {
                            "input_tokens": data.get("usage", {}).get("prompt_tokens", 0),
                            "output_tokens": data.get("usage", {}).get("completion_tokens", 0),
                        },
                        "stop_reason": data["choices"][0].get("finish_reason", "stop"),
                    }

            except Exception as e:
                self._stats["retries"] += 1
                logger.warning("DeepSeek API调用失败 (第%d次): %s", attempt + 1, e)
                if attempt < self.max_retries - 1:
                    wait_time = 2 ** attempt
                    await asyncio.sleep(wait_time)
                else:
                    self._stats["errors"] += 1
                    raise

        return {}

    async def _call_mock(
        self,
        system_prompt: str,
        user_message: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Mock LLM调用（开发/测试用）"""
        # 模拟API延迟
        await asyncio.sleep(0.5)

        # 从上下文中提取引用标记数量
        citation_count = user_message.count("[引用")

        # 生成模拟回答
        mock_content = f"""基于提供的合同条款，以下是审查意见：

**1. 报酬条款审查**
根据 [引用1]，合同中约定的报酬条款基本符合行业惯例。但需注意以下风险点：
- 付款节点与拍摄进度的关联性不够明确
- 建议增加"逾期付款"的违约金条款

**2. 知识产权条款审查**
根据 [引用2]，知识产权归属条款存在以下问题：
- 署名权的保障条款较为笼统，建议细化署名方式
- 未明确约定衍生作品的权利归属

**3. 违约责任条款审查**
根据 [引用3]，违约金比例（20%）在行业合理范围内，但：
- 建议增加"根本违约"的定义条款
- 不可抗力条款的适用范围建议明确化

**总结**: 该合同整体框架规范，但上述细节条款需要进一步完善。建议在签署前与专业律师确认修改方案。"""

        return {
            "content": mock_content,
            "model": "mock-llm",
            "usage": {"input_tokens": len(user_message) // 2, "output_tokens": len(mock_content) // 2},
            "stop_reason": "end_turn",
        }

    async def _stream_claude(
        self,
        system_prompt: str,
        user_message: str,
        temperature: Optional[float],
        max_tokens: Optional[int],
    ) -> AsyncGenerator[str, None]:
        """流式调用Claude"""
        # 实际实现使用SSE流式请求
        result = await self._call_claude(system_prompt, user_message, temperature, max_tokens)
        # 模拟流式输出（按句子分割）
        content = result["content"]
        for sentence in content.split("。"):
            if sentence.strip():
                yield sentence + "。"
                await asyncio.sleep(0.05)

    async def _stream_deepseek(
        self,
        system_prompt: str,
        user_message: str,
        temperature: Optional[float],
        max_tokens: Optional[int],
    ) -> AsyncGenerator[str, None]:
        """流式调用DeepSeek"""
        result = await self._call_deepseek(system_prompt, user_message, temperature, max_tokens)
        content = result["content"]
        for sentence in content.split("。"):
            if sentence.strip():
                yield sentence + "。"
                await asyncio.sleep(0.05)

    async def _stream_mock(
        self,
        system_prompt: str,
        user_message: str,
    ) -> AsyncGenerator[str, None]:
        """Mock流式输出"""
        result = await self._call_mock(system_prompt, user_message)
        content = result["content"]
        for char in content:
            yield char
            await asyncio.sleep(0.01)

    def get_stats(self) -> Dict[str, Any]:
        """获取调用统计"""
        return dict(self._stats)
