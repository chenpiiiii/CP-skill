"""
RAG生成编排模块

编排完整的RAG流程：检索 → Prompt构建 → LLM生成 → 引用溯源。
提供统一的query接口。
"""

from __future__ import annotations

import time
import logging
from typing import List, Optional, Dict, Any, AsyncGenerator

from config.settings import get_settings
from src.models.response import RAGResponse, Citation, ConfidenceLevel, StreamChunk
from src.models.search_result import SearchResult, RerankResult
from src.retrieval.hybrid_search import HybridSearcher
from src.generation.prompt_templates import PromptBuilder
from src.generation.llm_client import LLMClient
from src.generation.citation import CitationProcessor

logger = logging.getLogger(__name__)


class RAGPipeline:
    """
    RAG生成管道

    完整流程编排：
    1. 混合检索（向量 + BM25 → RRF → Rerank）
    2. Prompt构建（隔离区设计）
    3. LLM生成（支持流式）
    4. 引用溯源解析
    5. 响应组装

    延迟预算：P95 ≤ 10秒（其中LLM生成约8秒）
    """

    def __init__(
        self,
        hybrid_searcher: Optional[HybridSearcher] = None,
        llm_client: Optional[LLMClient] = None,
        use_mock: bool = False,
    ):
        """
        初始化RAG管道。

        Args:
            hybrid_searcher: 混合检索器（不传则自动创建）
            llm_client: LLM客户端（不传则自动创建）
            use_mock: 是否使用Mock模式
        """
        self.hybrid_searcher = hybrid_searcher or HybridSearcher(use_mock=use_mock)
        self.llm_client = llm_client or LLMClient()
        self.prompt_builder = PromptBuilder()
        self.citation_processor = CitationProcessor()
        self.use_mock = use_mock
        logger.info("RAG管道初始化完成 (mock=%s)", use_mock)

    async def query(
        self,
        question: str,
        mode: str = "default",
        top_k: int = 5,
        metadata_filter: Optional[Dict[str, Any]] = None,
    ) -> RAGResponse:
        """
        执行RAG问答。

        Args:
            question: 用户问题
            mode: 模式 "default" / "review" / "conflict_detection"
            top_k: 最终使用的上下文条数
            metadata_filter: 元数据过滤

        Returns:
            完整的RAG响应
        """
        start_time = time.time()
        logger.info("RAG问答开始: question='%s', mode=%s", question[:50], mode)

        # 步骤1：混合检索
        search_result = self.hybrid_searcher.search(
            query=question,
            top_k=top_k,
            metadata_filter=metadata_filter,
        )
        logger.info("检索完成: %d条结果, %.1fms", len(search_result.results), search_result.search_time_ms)

        # 步骤2：构建Prompt
        prompts = self.prompt_builder.build_prompt(
            query=question,
            contexts=search_result.results,
            mode=mode,
        )

        # 步骤3：LLM生成
        try:
            llm_result = await self.llm_client.generate(
                system_prompt=prompts["system"],
                user_message=prompts["user"],
            )
            llm_output = llm_result["content"]
        except Exception as e:
            logger.error("LLM生成失败: %s", e)
            return self._build_error_response(question, str(e))

        # 步骤4：引用溯源
        clean_output, citations = self.citation_processor.process_citations(
            llm_output=llm_output,
            contexts=search_result.results,
        )

        # 步骤5：解析审查发现项（如果是审查模式）
        findings = []
        if mode == "review":
            findings = self.citation_processor.parse_review_findings(
                llm_output=clean_output,
                contexts=search_result.results,
                citations=citations,
            )

        # 步骤6：评估置信度
        confidence = self.citation_processor.assess_confidence(citations, clean_output)

        # 步骤7：组装响应
        total_time = (time.time() - start_time) * 1000
        response = RAGResponse(
            query=question,
            answer=clean_output,
            answer_type=mode,
            confidence=confidence,
            citations=citations,
            findings=findings,
            context_chunks=[
                {
                    "chunk_id": r.chunk_id,
                    "content": r.content[:200],
                    "document_name": r.document_name,
                    "hierarchy_path": r.hierarchy_path,
                    "rerank_score": r.rerank_score,
                }
                for r in search_result.results
            ],
            generation_time_ms=total_time,
            model_used=llm_result.get("model", "unknown"),
            metadata={
                "search_time_ms": search_result.search_time_ms,
                "total_candidates": search_result.total_candidates,
                "llm_usage": llm_result.get("usage", {}),
            },
        )

        logger.info(
            "RAG问答完成: confidence=%s, citations=%d, time=%.1fms",
            confidence.value, len(citations), total_time,
        )
        return response

    async def query_stream(
        self,
        question: str,
        mode: str = "default",
        top_k: int = 5,
        metadata_filter: Optional[Dict[str, Any]] = None,
    ) -> AsyncGenerator[StreamChunk, None]:
        """
        流式RAG问答。

        Args:
            question: 用户问题
            mode: 模式
            top_k: 上下文条数
            metadata_filter: 元数据过滤

        Yields:
            流式数据块
        """
        # 先执行检索
        search_result = self.hybrid_searcher.search(
            query=question,
            top_k=top_k,
            metadata_filter=metadata_filter,
        )

        # 构建Prompt
        prompts = self.prompt_builder.build_prompt(
            query=question,
            contexts=search_result.results,
            mode=mode,
        )

        # 流式LLM生成
        accumulated_text = ""
        async for chunk_text in self.llm_client.generate_stream(
            system_prompt=prompts["system"],
            user_message=prompts["user"],
        ):
            accumulated_text += chunk_text
            yield StreamChunk(chunk_type="text", content=chunk_text)

        # 处理引用
        _, citations = self.citation_processor.process_citations(
            llm_output=accumulated_text,
            contexts=search_result.results,
        )

        # 发送引用信息
        for citation in citations:
            yield StreamChunk(chunk_type="citation", citation=citation)

        # 发送完成信号
        yield StreamChunk(
            chunk_type="done",
            metadata={"total_citations": len(citations)},
        )

    def _build_error_response(self, question: str, error_msg: str) -> RAGResponse:
        """构建错误响应"""
        return RAGResponse(
            query=question,
            answer=f"抱歉，处理您的问题时遇到了错误：{error_msg}。请稍后重试。",
            confidence=ConfidenceLevel.LOW,
            warnings=[f"LLM调用错误: {error_msg}"],
            generation_time_ms=0,
        )
