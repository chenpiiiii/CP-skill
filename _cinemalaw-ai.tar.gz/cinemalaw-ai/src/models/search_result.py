"""
检索结果数据模型

定义混合检索、RRF融合、重排各环节的数据结构。
"""

from __future__ import annotations

from enum import Enum
from typing import Optional, List, Dict, Any

from pydantic import BaseModel, Field


class SearchSource(str, Enum):
    """检索来源"""
    VECTOR = "vector"
    BM25 = "bm25"
    HYBRID = "hybrid"


class RetrievalResult(BaseModel):
    """单条检索结果"""
    chunk_id: str = Field(description="对应的Chunk ID")
    content: str = Field(description="Chunk文本内容")
    score: float = Field(default=0.0, description="检索分数")
    source: SearchSource = Field(default=SearchSource.VECTOR, description="检索来源")
    rank: int = Field(default=0, description="在结果列表中的排名")

    # 关联的元数据
    document_id: str = Field(default="", description="文档ID")
    document_name: str = Field(default="", description="文档名称")
    hierarchy_path: str = Field(default="", description="层级路径")
    page_range: List[int] = Field(default_factory=list, description="页码范围")
    category: str = Field(default="", description="分类")

    # 扩展信息
    metadata: Dict[str, Any] = Field(default_factory=dict, description="扩展元数据")


class RRFResult(BaseModel):
    """RRF融合后的结果"""
    chunk_id: str = Field(description="Chunk ID")
    content: str = Field(description="文本内容")
    rrf_score: float = Field(description="RRF融合分数")
    bm25_rank: Optional[int] = Field(default=None, description="BM25排名")
    vector_rank: Optional[int] = Field(default=None, description="向量检索排名")
    bm25_score: float = Field(default=0.0, description="BM25原始分数")
    vector_score: float = Field(default=0.0, description="向量检索原始分数")

    # 关联元数据
    document_id: str = Field(default="")
    document_name: str = Field(default="")
    hierarchy_path: str = Field(default="")
    page_range: List[int] = Field(default_factory=list)
    category: str = Field(default="")


class RerankResult(BaseModel):
    """重排后的结果"""
    chunk_id: str = Field(description="Chunk ID")
    content: str = Field(description="文本内容")
    rerank_score: float = Field(description="重排分数（0-1之间）")
    rrf_score: float = Field(default=0.0, description="RRF融合分数")
    rank: int = Field(default=0, description="最终排名")

    # 关联元数据
    document_id: str = Field(default="")
    document_name: str = Field(default="")
    hierarchy_path: str = Field(default="")
    page_range: List[int] = Field(default_factory=list)
    category: str = Field(default="")


class SearchResult(BaseModel):
    """最终检索结果集"""
    query: str = Field(description="原始查询")
    rewritten_query: str = Field(default="", description="改写后的查询")
    results: List[RerankResult] = Field(default_factory=list, description="最终排序结果")
    total_candidates: int = Field(default=0, description="初始候选数量")
    search_time_ms: float = Field(default=0.0, description="检索总耗时（毫秒）")
    search_metadata: Dict[str, Any] = Field(default_factory=dict, description="检索过程元数据")
