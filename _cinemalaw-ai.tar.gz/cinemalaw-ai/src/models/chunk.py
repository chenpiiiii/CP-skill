"""
Chunk数据模型

定义文本切片的标准数据结构，包含层级信息和元数据。
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any

from pydantic import BaseModel, Field


class Chunk(BaseModel):
    """
    文本切片模型

    每个Chunk代表文档中的一个语义完整片段，携带完整的层级路径信息，
    用于支持精确的法律条款定位和溯源。
    """
    chunk_id: str = Field(default_factory=lambda: str(uuid.uuid4()), description="切片唯一ID")
    document_id: str = Field(description="所属文档ID")
    document_name: str = Field(default="", description="所属文档名称")
    content: str = Field(description="切片文本内容")
    chunk_index: int = Field(default=0, description="在文档中的顺序编号")
    token_count: int = Field(default=0, description="该chunk的token数量")

    # 层级信息
    hierarchy_path: str = Field(default="", description="层级路径，如 '第三章-报酬条款/3.2-分成比例'")
    hierarchy_level: int = Field(default=0, description="层级深度: 0=编, 1=章, 2=节, 3=条, 4=款, 5=项")
    parent_chunk_id: Optional[str] = Field(default=None, description="父级chunk ID")

    # 位置信息
    page_range: List[int] = Field(default_factory=list, description="页码范围 [起始页, 结束页]")
    start_offset: int = Field(default=0, description="在原文中的起始字符偏移")
    end_offset: int = Field(default=0, description="在原文中的结束字符偏移")

    # 元数据
    category: str = Field(default="", description="二级分类，如 '分成条款'/'知识产权'/'违约责任'")
    keywords: List[str] = Field(default_factory=list, description="关键词列表")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="创建时间")
    extra: Dict[str, Any] = Field(default_factory=dict, description="扩展元数据")

    def to_dict_for_index(self) -> Dict[str, Any]:
        """转换为适合索引的字典格式"""
        return {
            "chunk_id": self.chunk_id,
            "document_id": self.document_id,
            "document_name": self.document_name,
            "content": self.content,
            "chunk_index": self.chunk_index,
            "token_count": self.token_count,
            "hierarchy_path": self.hierarchy_path,
            "hierarchy_level": self.hierarchy_level,
            "parent_chunk_id": self.parent_chunk_id,
            "page_range": self.page_range,
            "category": self.category,
            "keywords": self.keywords,
            "timestamp": self.timestamp.isoformat(),
        }

    def get_context_window(self, prefix_tokens: int = 100) -> str:
        """获取带上下文前缀的内容（用于检索时提供更多上下文）"""
        if self.hierarchy_path:
            return f"[{self.hierarchy_path}]\n{self.content}"
        return self.content


class ChunkBatch(BaseModel):
    """批量切片结果"""
    document_id: str = Field(description="文档ID")
    chunks: List[Chunk] = Field(default_factory=list, description="切片列表")
    total_tokens: int = Field(default=0, description="总token数")
    total_chunks: int = Field(default=0, description="总切片数")
    processing_time_seconds: float = Field(default=0.0, description="处理耗时")

    def calculate_stats(self) -> None:
        """计算统计信息"""
        self.total_chunks = len(self.chunks)
        self.total_tokens = sum(c.token_count for c in self.chunks)
