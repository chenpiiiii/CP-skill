"""
文档数据模型

定义文档解析后的标准数据结构，包含文档元信息和版面元素。
"""

from __future__ import annotations

import uuid
from datetime import datetime
from enum import Enum
from typing import Optional, List, Dict, Any

from pydantic import BaseModel, Field


class DocumentType(str, Enum):
    """影视合同文档类型枚举"""
    ACTOR_CONTRACT = "actor_contract"           # 演员经纪合同
    COPYRIGHT_LICENSE = "copyright_license"      # 版权授权合同
    CO_INVESTMENT = "co_investment"              # 联合投资合同
    DISTRIBUTION = "distribution"                # 发行合同
    WRITER_COMMISSION = "writer_commission"      # 编剧委托合同
    OTHER = "other"                              # 其他


class ElementType(str, Enum):
    """文档版面元素类型"""
    TITLE = "title"          # 标题
    TEXT = "text"            # 正文段落
    TABLE = "table"          # 表格
    IMAGE = "image"          # 图片
    HEADER = "header"        # 页眉
    FOOTER = "footer"        # 页脚
    PAGE_NUMBER = "page_number"  # 页码
    SEAL = "seal"            # 印章
    SIGNATURE = "signature"  # 签名区域


class BoundingBox(BaseModel):
    """元素边界框坐标"""
    x_min: float = Field(description="左边界x坐标")
    y_min: float = Field(description="上边界y坐标")
    x_max: float = Field(description="右边界x坐标")
    y_max: float = Field(description="下边界y坐标")
    page: int = Field(default=0, description="所在页码（从0开始）")

    @property
    def width(self) -> float:
        """元素宽度"""
        return self.x_max - self.x_min

    @property
    def height(self) -> float:
        """元素高度"""
        return self.y_max - self.y_min


class DocumentElement(BaseModel):
    """文档版面元素"""
    element_id: str = Field(default_factory=lambda: str(uuid.uuid4()), description="元素唯一ID")
    element_type: ElementType = Field(description="元素类型")
    content: str = Field(description="元素文本内容")
    bbox: Optional[BoundingBox] = Field(default=None, description="边界框坐标")
    confidence: float = Field(default=1.0, ge=0.0, le=1.0, description="识别置信度")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="扩展元数据")


class DocumentMetadata(BaseModel):
    """文档级元数据"""
    document_name: str = Field(description="原始文件名")
    document_type: DocumentType = Field(default=DocumentType.OTHER, description="合同类型")
    total_pages: int = Field(default=0, description="总页数")
    file_size_bytes: int = Field(default=0, description="文件大小（字节）")
    file_hash: str = Field(default="", description="文件MD5哈希")
    upload_time: datetime = Field(default_factory=datetime.utcnow, description="上传时间")
    extra: Dict[str, Any] = Field(default_factory=dict, description="扩展元数据")


class ParsedDocument(BaseModel):
    """解析后的完整文档结构"""
    document_id: str = Field(default_factory=lambda: str(uuid.uuid4()), description="文档唯一ID")
    metadata: DocumentMetadata = Field(description="文档元数据")
    elements: List[DocumentElement] = Field(default_factory=list, description="版面元素列表")
    plain_text: str = Field(default="", description="纯文本内容（所有文本元素拼接）")
    parse_time_seconds: float = Field(default=0.0, description="解析耗时（秒）")
    parse_status: str = Field(default="success", description="解析状态: success/partial/failed")
    parse_errors: List[str] = Field(default_factory=list, description="解析错误信息")

    def get_elements_by_type(self, element_type: ElementType) -> List[DocumentElement]:
        """按类型筛选元素"""
        return [e for e in self.elements if e.element_type == element_type]

    def get_text_elements(self) -> List[DocumentElement]:
        """获取所有文本类型元素"""
        return self.get_elements_by_type(ElementType.TEXT)

    def get_table_elements(self) -> List[DocumentElement]:
        """获取所有表格元素"""
        return self.get_elements_by_type(ElementType.TABLE)

    def to_markdown(self) -> str:
        """将文档转换为Markdown格式"""
        parts = []
        for elem in self.elements:
            if elem.element_type == ElementType.TITLE:
                parts.append(f"## {elem.content}\n")
            elif elem.element_type == ElementType.TEXT:
                parts.append(f"{elem.content}\n")
            elif elem.element_type == ElementType.TABLE:
                parts.append(f"{elem.content}\n")  # 表格内容已是Markdown格式
            elif elem.element_type == ElementType.IMAGE:
                parts.append(f"[图片: {elem.metadata.get('description', '')}]\n")
        return "\n".join(parts)
