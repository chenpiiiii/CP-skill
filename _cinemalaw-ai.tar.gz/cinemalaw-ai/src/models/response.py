"""
响应数据模型

定义RAG生成后的最终响应结构，包含引用溯源信息。
"""

from __future__ import annotations

from enum import Enum
from typing import Optional, List, Dict, Any

from pydantic import BaseModel, Field


class ConfidenceLevel(str, Enum):
    """回答置信度级别"""
    HIGH = "high"          # 高置信度：多个相关chunk支撑
    MEDIUM = "medium"      # 中置信度：有相关chunk但信息不够充分
    LOW = "low"            # 低置信度：相关度较低，建议人工复核
    NO_EVIDENCE = "no_evidence"  # 无证据：未找到相关信息


class Citation(BaseModel):
    """引用溯源信息"""
    citation_id: int = Field(description="引用编号（从1开始）")
    chunk_id: str = Field(description="引用的Chunk ID")
    document_name: str = Field(default="", description="来源文档名称")
    hierarchy_path: str = Field(default="", description="条款层级路径")
    page_range: List[int] = Field(default_factory=list, description="页码范围")
    relevant_text: str = Field(default="", description="原文中最相关的片段")
    relevance_score: float = Field(default=0.0, description="相关度分数")


class ReviewFinding(BaseModel):
    """审查发现项"""
    finding_id: str = Field(description="发现项ID")
    severity: str = Field(description="严重程度: critical/high/medium/low/info")
    category: str = Field(description="分类：如'违约责任'/'知识产权'/'分成条款'")
    description: str = Field(description="问题描述")
    recommendation: str = Field(default="", description="修改建议")
    citations: List[Citation] = Field(default_factory=list, description="引用溯源")
    confidence: ConfidenceLevel = Field(default=ConfidenceLevel.MEDIUM, description="置信度")


class RAGResponse(BaseModel):
    """RAG完整响应"""
    query: str = Field(description="用户原始问题")
    answer: str = Field(description="生成的回答")
    answer_type: str = Field(default="qa", description="回答类型: qa/review/conflict_detection")
    confidence: ConfidenceLevel = Field(default=ConfidenceLevel.MEDIUM, description="整体置信度")
    citations: List[Citation] = Field(default_factory=list, description="引用列表")
    findings: List[ReviewFinding] = Field(default_factory=list, description="审查发现项列表")
    context_chunks: List[Dict[str, Any]] = Field(default_factory=list, description="使用的上下文Chunk")
    generation_time_ms: float = Field(default=0.0, description="生成耗时（毫秒）")
    model_used: str = Field(default="", description="使用的LLM模型")
    warnings: List[str] = Field(default_factory=list, description="警告信息")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="扩展元数据")


class StreamChunk(BaseModel):
    """流式输出的单个数据块"""
    chunk_type: str = Field(description="块类型: text/citation/done")
    content: str = Field(default="", description="文本内容")
    citation: Optional[Citation] = Field(default=None, description="引用信息")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="元数据")
