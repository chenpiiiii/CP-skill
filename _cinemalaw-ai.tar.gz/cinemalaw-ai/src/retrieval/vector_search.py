"""
向量检索模块

集成 BGE-M3 模型进行文本向量化，通过 Milvus 进行高效的向量相似度检索。
支持 Mock 实现和真实实现两种模式。
"""

from __future__ import annotations

import time
import logging
from typing import List, Optional, Dict, Any

from config.settings import get_settings
from src.models.search_result import RetrievalResult, SearchSource

logger = logging.getLogger(__name__)


class BGEEmbedder:
    """
    BGE-M3 Embedding模型封装

    支持本地模型和远程推理服务两种模式。
    """

    def __init__(self, use_mock: bool = False):
        """
        初始化Embedding模型。

        Args:
            use_mock: 是否使用Mock模式
        """
        settings = get_settings()
        self.use_mock = use_mock
        self.model_path = settings.bge_m3_model_path
        self.use_gpu = settings.bge_m3_use_gpu
        self.batch_size = settings.bge_m3_batch_size
        self.max_length = settings.bge_m3_max_length
        self._model = None
        self._dim = settings.milvus_dim

        if not use_mock and not settings.bge_m3_use_remote:
            self._load_model()
        logger.info("BGE-M3 Embedder初始化: mock=%s, dim=%d", use_mock, self._dim)

    def _load_model(self) -> None:
        """加载本地模型"""
        try:
            from transformers import AutoTokenizer, AutoModel
            import torch

            device = "cuda:0" if self.use_gpu else "cpu"
            self._model = {
                "tokenizer": AutoTokenizer.from_pretrained(self.model_path),
                "model": AutoModel.from_pretrained(self.model_path).to(device),
                "device": device,
            }
            logger.info("BGE-M3 本地模型加载完成")
        except Exception as e:
            logger.warning("BGE-M3 本地模型加载失败，降级为Mock模式: %s", e)
            self.use_mock = True

    def encode(self, texts: List[str]) -> List[List[float]]:
        """
        将文本列表编码为向量。

        Args:
            texts: 待编码的文本列表

        Returns:
            向量列表（每个向量为float列表）
        """
        if self.use_mock:
            return self._mock_encode(texts)

        if get_settings().bge_m3_use_remote:
            return self._remote_encode(texts)

        return self._local_encode(texts)

    def encode_query(self, query: str) -> List[float]:
        """
        编码单个查询。

        Args:
            query: 查询文本

        Returns:
            查询向量
        """
        vectors = self.encode([query])
        return vectors[0]

    def _local_encode(self, texts: List[str]) -> List[List[float]]:
        """本地模型编码"""
        import torch

        model_data = self._model
        tokenizer = model_data["tokenizer"]
        model = model_data["model"]
        device = model_data["device"]

        all_vectors = []

        for i in range(0, len(texts), self.batch_size):
            batch = texts[i:i + self.batch_size]
            encoded = tokenizer(
                batch,
                padding=True,
                truncation=True,
                max_length=self.max_length,
                return_tensors="pt",
            ).to(device)

            with torch.no_grad():
                outputs = model(**encoded)
                # 使用CLS token的表示作为向量
                vectors = outputs.last_hidden_state[:, 0, :]
                # L2归一化
                vectors = torch.nn.functional.normalize(vectors, p=2, dim=1)
                all_vectors.extend(vectors.cpu().numpy().tolist())

        return all_vectors

    def _remote_encode(self, texts: List[str]) -> List[List[float]]:
        """远程推理服务编码"""
        import httpx

        endpoint = get_settings().bge_m3_endpoint
        response = httpx.post(
            f"{endpoint}/encode",
            json={"texts": texts},
            timeout=30.0,
        )
        response.raise_for_status()
        return response.json()["vectors"]

    def _mock_encode(self, texts: List[str]) -> List[List[float]]:
        """Mock编码：生成基于文本哈希的伪向量（用于测试）"""
        import hashlib
        vectors = []
        for text in texts:
            # 基于文本内容生成确定性伪向量
            hash_bytes = hashlib.sha256(text.encode()).digest()
            # 扩展到目标维度
            vector = []
            for i in range(self._dim):
                byte_idx = i % len(hash_bytes)
                value = (hash_bytes[byte_idx] + i) % 256
                vector.append((value / 255.0) * 2 - 1)  # 归一化到[-1, 1]
            # L2归一化
            norm = sum(v * v for v in vector) ** 0.5
            if norm > 0:
                vector = [v / norm for v in vector]
            vectors.append(vector)
        return vectors

    @property
    def dimension(self) -> int:
        """向量维度"""
        return self._dim


class VectorSearcher:
    """
    向量检索器

    集成BGE-M3模型和Milvus向量数据库，提供高效的语义检索能力。
    """

    def __init__(self, embedder: Optional[BGEEmbedder] = None, use_mock: bool = False):
        """
        初始化向量检索器。

        Args:
            embedder: Embedding模型实例
            use_mock: 是否使用Mock模式
        """
        self.use_mock = use_mock or (embedder is not None and embedder.use_mock)
        self.embedder = embedder or BGEEmbedder(use_mock=self.use_mock)
        self.settings = get_settings()
        self._collection = None

        if not self.use_mock:
            self._init_milvus()

        logger.info("向量检索器初始化: mock=%s", self.use_mock)

    def _init_milvus(self) -> None:
        """初始化Milvus连接"""
        try:
            from pymilvus import connections, Collection
            connections.connect(host=self.settings.milvus_host, port=self.settings.milvus_port)
            self._collection = Collection(self.settings.milvus_collection)
            self._collection.load()
            logger.info("Milvus连接成功，集合已加载: %s", self.settings.milvus_collection)
        except Exception as e:
            logger.warning("Milvus连接失败，降级为Mock模式: %s", e)
            self.use_mock = True

    def search(
        self,
        query: str,
        top_k: int = 30,
        metadata_filter: Optional[Dict[str, Any]] = None,
    ) -> List[RetrievalResult]:
        """
        执行向量检索。

        Args:
            query: 查询文本
            top_k: 返回结果数量
            metadata_filter: 元数据过滤条件

        Returns:
            检索结果列表
        """
        start_time = time.time()

        # 编码查询
        query_vector = self.embedder.encode_query(query)

        if self.use_mock:
            results = self._mock_search(query, top_k)
        else:
            results = self._milvus_search(query_vector, top_k, metadata_filter)

        elapsed = (time.time() - start_time) * 1000
        logger.debug("向量检索完成: query='%s', 结果数=%d, 耗时=%.1fms", query[:30], len(results), elapsed)
        return results

    def _milvus_search(
        self,
        query_vector: List[float],
        top_k: int,
        metadata_filter: Optional[Dict[str, Any]] = None,
    ) -> List[RetrievalResult]:
        """Milvus向量检索"""
        from pymilvus import Collection

        search_params = {"metric_type": self.settings.milvus_metric, "params": {"nprobe": self.settings.milvus_nprobe}}

        # 构建过滤表达式
        expr = None
        if metadata_filter:
            conditions = []
            for key, value in metadata_filter.items():
                if isinstance(value, str):
                    conditions.append(f'{key} == "{value}"')
                else:
                    conditions.append(f"{key} == {value}")
            expr = " and ".join(conditions)

        results = self._collection.search(
            data=[query_vector],
            anns_field="embedding",
            param=search_params,
            limit=top_k,
            expr=expr,
            output_fields=["chunk_id", "content", "document_id", "document_name",
                          "hierarchy_path", "page_range", "category"],
        )

        retrieval_results = []
        for rank, hit in enumerate(results[0]):
            retrieval_results.append(RetrievalResult(
                chunk_id=hit.entity.get("chunk_id"),
                content=hit.entity.get("content"),
                score=hit.score,
                source=SearchSource.VECTOR,
                rank=rank,
                document_id=hit.entity.get("document_id", ""),
                document_name=hit.entity.get("document_name", ""),
                hierarchy_path=hit.entity.get("hierarchy_path", ""),
                page_range=hit.entity.get("page_range", []),
                category=hit.entity.get("category", ""),
            ))

        return retrieval_results

    def _mock_search(self, query: str, top_k: int) -> List[RetrievalResult]:
        """Mock向量检索：返回模拟结果"""
        results = []
        for i in range(min(top_k, 5)):
            results.append(RetrievalResult(
                chunk_id=f"mock_chunk_{i:03d}",
                content=f"[Mock向量检索结果 #{i+1}] 与查询 '{query[:30]}' 相关的合同条款内容...",
                score=0.95 - i * 0.05,
                source=SearchSource.VECTOR,
                rank=i,
                document_id="mock_doc_001",
                document_name="模拟演员经纪合同.pdf",
                hierarchy_path=f"第{(i % 3) + 1}章 / 第{(i % 5) + 1}条",
                page_range=[i % 5],
                category=["报酬与支付", "知识产权", "违约责任", "工作期限", "保密条款"][i % 5],
            ))
        return results

    def batch_insert(self, chunks_data: List[Dict[str, Any]]) -> int:
        """
        批量插入向量数据。

        Args:
            chunks_data: Chunk数据列表（含content和其他元数据）

        Returns:
            成功插入的数量
        """
        if self.use_mock:
            logger.info("[Mock] 批量插入 %d 条向量数据", len(chunks_data))
            return len(chunks_data)

        # 编码所有文本
        texts = [c["content"] for c in chunks_data]
        vectors = self.embedder.encode(texts)

        # 构建插入数据
        insert_data = []
        for chunk, vector in zip(chunks_data, vectors):
            insert_data.append({
                "chunk_id": chunk["chunk_id"],
                "embedding": vector,
                "content": chunk["content"],
                "document_id": chunk["document_id"],
                "document_name": chunk.get("document_name", ""),
                "hierarchy_path": chunk.get("hierarchy_path", ""),
                "category": chunk.get("category", ""),
            })

        self._collection.insert(insert_data)
        logger.info("成功插入 %d 条向量数据到Milvus", len(insert_data))
        return len(insert_data)
