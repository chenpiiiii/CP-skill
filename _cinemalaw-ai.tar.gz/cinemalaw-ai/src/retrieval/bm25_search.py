"""
BM25检索模块

集成 Elasticsearch 进行BM25全文检索，支持中文分词配置。
"""

from __future__ import annotations

import time
import logging
from typing import List, Optional, Dict, Any

from config.settings import get_settings
from src.models.search_result import RetrievalResult, SearchSource

logger = logging.getLogger(__name__)


class BM25Searcher:
    """
    BM25检索器

    基于Elasticsearch的BM25全文检索，支持中文分词（IK Analyzer）。
    提供Mock实现用于开发测试环境。
    """

    def __init__(self, use_mock: bool = False):
        """
        初始化BM25检索器。

        Args:
            use_mock: 是否使用Mock模式
        """
        self.settings = get_settings()
        self.use_mock = use_mock
        self._client = None

        if not use_mock:
            self._init_elasticsearch()

        logger.info("BM25检索器初始化: mock=%s", use_mock)

    def _init_elasticsearch(self) -> None:
        """初始化Elasticsearch连接"""
        try:
            from elasticsearch import Elasticsearch

            self._client = Elasticsearch(
                self.settings.es_url,
                basic_auth=(self.settings.es_username, self.settings.es_password),
                request_timeout=self.settings.es_timeout,
            )
            # 测试连接
            info = self._client.info()
            logger.info("Elasticsearch连接成功: %s", info.get("version", {}).get("number", "unknown"))
        except Exception as e:
            logger.warning("Elasticsearch连接失败，降级为Mock模式: %s", e)
            self.use_mock = True

    def search(
        self,
        query: str,
        top_k: int = 30,
        metadata_filter: Optional[Dict[str, Any]] = None,
    ) -> List[RetrievalResult]:
        """
        执行BM25检索。

        Args:
            query: 查询文本
            top_k: 返回结果数量
            metadata_filter: 元数据过滤条件

        Returns:
            检索结果列表
        """
        start_time = time.time()

        if self.use_mock:
            results = self._mock_search(query, top_k)
        else:
            results = self._es_search(query, top_k, metadata_filter)

        elapsed = (time.time() - start_time) * 1000
        logger.debug("BM25检索完成: query='%s', 结果数=%d, 耗时=%.1fms", query[:30], len(results), elapsed)
        return results

    def _es_search(
        self,
        query: str,
        top_k: int,
        metadata_filter: Optional[Dict[str, Any]] = None,
    ) -> List[RetrievalResult]:
        """Elasticsearch BM25检索"""
        index_name = f"{self.settings.es_index_prefix}_chunks"

        # 构建查询体
        body: Dict[str, Any] = {
            "size": top_k,
            "query": {
                "bool": {
                    "must": [
                        {
                            "multi_match": {
                                "query": query,
                                "fields": ["content^3", "hierarchy_path^2", "category"],
                                "type": "best_fields",
                                "analyzer": "ik_smart",
                            }
                        }
                    ]
                }
            },
        }

        # 添加元数据过滤
        if metadata_filter:
            for key, value in metadata_filter.items():
                body["query"]["bool"]["filter"].append({"term": {key: value}})

        try:
            response = self._client.search(index=index_name, body=body)
        except Exception as e:
            logger.error("ES查询失败: %s", e)
            return []

        results = []
        hits = response.get("hits", {}).get("hits", [])

        for rank, hit in enumerate(hits):
            source = hit["_source"]
            results.append(RetrievalResult(
                chunk_id=source.get("chunk_id", hit["_id"]),
                content=source.get("content", ""),
                score=hit["_score"],
                source=SearchSource.BM25,
                rank=rank,
                document_id=source.get("document_id", ""),
                document_name=source.get("document_name", ""),
                hierarchy_path=source.get("hierarchy_path", ""),
                page_range=source.get("page_range", []),
                category=source.get("category", ""),
            ))

        return results

    def _mock_search(self, query: str, top_k: int) -> List[RetrievalResult]:
        """Mock BM25检索"""
        results = []
        for i in range(min(top_k, 5)):
            results.append(RetrievalResult(
                chunk_id=f"mock_bm25_{i:03d}",
                content=f"[Mock BM25结果 #{i+1}] 包含关键词 '{query[:20]}' 的合同条款...",
                score=15.0 - i * 1.5,
                source=SearchSource.BM25,
                rank=i,
                document_id="mock_doc_001",
                document_name="模拟演员经纪合同.pdf",
                hierarchy_path=f"第{(i % 3) + 1}章 / 第{(i % 5) + 7}条",
                page_range=[i % 5],
                category=["报酬与支付", "违约责任", "知识产权", "工作期限", "保密条款"][i % 5],
            ))
        return results

    def batch_index(self, chunks_data: List[Dict[str, Any]]) -> int:
        """
        批量索引文档到Elasticsearch。

        Args:
            chunks_data: Chunk数据列表

        Returns:
            成功索引的数量
        """
        if self.use_mock:
            logger.info("[Mock] 批量索引 %d 条文档到ES", len(chunks_data))
            return len(chunks_data)

        from elasticsearch.helpers import bulk

        index_name = f"{self.settings.es_index_prefix}_chunks"
        actions = []
        for chunk in chunks_data:
            actions.append({
                "_index": index_name,
                "_id": chunk["chunk_id"],
                "_source": {
                    "content": chunk["content"],
                    "document_id": chunk["document_id"],
                    "document_name": chunk.get("document_name", ""),
                    "hierarchy_path": chunk.get("hierarchy_path", ""),
                    "category": chunk.get("category", ""),
                    "keywords": chunk.get("keywords", []),
                    "chunk_index": chunk.get("chunk_index", 0),
                    "page_range": chunk.get("page_range", []),
                    "token_count": chunk.get("token_count", 0),
                },
            })

        success, _ = bulk(self._client, actions, chunk_size=self.settings.es_chunk_size)
        logger.info("成功索引 %d 条文档到Elasticsearch", success)
        return success

    def get_index_stats(self) -> Dict[str, Any]:
        """获取索引统计信息"""
        if self.use_mock:
            return {"status": "mock", "doc_count": 0}

        try:
            index_name = f"{self.settings.es_index_prefix}_chunks"
            stats = self._client.indices.stats(index=index_name)
            return {
                "status": "connected",
                "doc_count": stats["_all"]["primaries"]["docs"]["count"],
                "store_size_bytes": stats["_all"]["primaries"]["store"]["size_in_bytes"],
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}
