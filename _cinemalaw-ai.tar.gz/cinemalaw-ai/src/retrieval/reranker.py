"""
BGE-Reranker精排模块

使用BGE-Reranker-Large对RRF融合后的候选结果进行精细化重排序。
采用交叉编码器（Cross-Encoder）架构，对(query, document)对进行精细语义匹配。
"""

from __future__ import annotations

import time
import logging
from typing import List, Optional, Tuple

from config.settings import get_settings
from src.models.search_result import RRFResult, RerankResult

logger = logging.getLogger(__name__)


class Reranker:
    """
    BGE-Reranker-Large 重排器

    对RRF融合后的候选结果进行精细重排序：
    1. 将(query, chunk)对输入Cross-Encoder模型
    2. 模型输出相关性分数（0-1之间）
    3. 按分数重新排序
    4. 过滤低于阈值的候选
    5. 返回Top-K结果

    支持Mock模式和真实模式，通过配置切换。
    """

    def __init__(self, use_mock: bool = False):
        """
        初始化重排器。

        Args:
            use_mock: 是否使用Mock模式
        """
        settings = get_settings()
        self.use_mock = use_mock
        self.threshold = settings.reranker_threshold
        self.top_k = settings.reranker_top_k
        self.model_path = settings.reranker_model_path
        self.use_gpu = settings.reranker_use_gpu
        self._model = None
        self._tokenizer = None

        if not use_mock and not settings.reranker_use_remote:
            self._load_model()

        logger.info(
            "Reranker初始化: mock=%s, threshold=%.2f, top_k=%d",
            use_mock, self.threshold, self.top_k,
        )

    def _load_model(self) -> None:
        """加载Reranker模型"""
        try:
            from transformers import AutoTokenizer, AutoModelForSequenceClassification
            import torch

            device = "cuda:0" if self.use_gpu else "cpu"
            self._tokenizer = AutoTokenizer.from_pretrained(self.model_path)
            self._model = AutoModelForSequenceClassification.from_pretrained(self.model_path)
            self._model.to(device)
            self._model.eval()
            logger.info("BGE-Reranker模型加载完成: %s, device=%s", self.model_path, device)
        except Exception as e:
            logger.warning("Reranker模型加载失败，降级为Mock模式: %s", e)
            self.use_mock = True

    def rerank(
        self,
        query: str,
        candidates: List[RRFResult],
        top_k: Optional[int] = None,
        threshold: Optional[float] = None,
    ) -> List[RerankResult]:
        """
        对候选结果进行重排序。

        Args:
            query: 用户查询
            candidates: RRF融合后的候选结果列表
            top_k: 返回条数（None使用默认配置）
            threshold: 分数阈值（None使用默认配置）

        Returns:
            重排后的结果列表
        """
        if not candidates:
            return []

        k = top_k or self.top_k
        thresh = threshold if threshold is not None else self.threshold
        start_time = time.time()

        if self.use_mock:
            scores = self._mock_rerank(query, candidates)
        elif get_settings().reranker_use_remote:
            scores = self._remote_rerank(query, candidates)
        else:
            scores = self._local_rerank(query, candidates)

        # 构建重排结果
        rerank_results = []
        for candidate, score in zip(candidates, scores):
            if score >= thresh:
                rerank_results.append(RerankResult(
                    chunk_id=candidate.chunk_id,
                    content=candidate.content,
                    rerank_score=score,
                    rrf_score=candidate.rrf_score,
                    document_id=candidate.document_id,
                    document_name=candidate.document_name,
                    hierarchy_path=candidate.hierarchy_path,
                    page_range=candidate.page_range,
                    category=candidate.category,
                ))

        # 按重排分数降序排列
        rerank_results.sort(key=lambda x: x.rerank_score, reverse=True)

        # 取Top-K
        rerank_results = rerank_results[:k]

        # 更新最终排名
        for i, result in enumerate(rerank_results):
            result.rank = i

        elapsed = (time.time() - start_time) * 1000
        logger.info(
            "重排完成: %d 候选 → %d 通过阈值(%.2f) → Top-%d, 耗时=%.1fms",
            len(candidates), len(rerank_results), thresh, k, elapsed,
        )
        return rerank_results

    def _local_rerank(self, query: str, candidates: List[RRFResult]) -> List[float]:
        """本地模型重排"""
        import torch

        scores = []
        batch_size = 32  # 分批推理

        for i in range(0, len(candidates), batch_size):
            batch = candidates[i:i + batch_size]
            pairs = [(query, c.content) for c in batch]

            encoded = self._tokenizer(
                pairs,
                padding=True,
                truncation=True,
                max_length=512,
                return_tensors="pt",
            ).to(self._model.device)

            with torch.no_grad():
                logits = self._model(**encoded).logits
                # sigmoid激活，映射到0-1
                batch_scores = torch.sigmoid(logits).squeeze(-1).cpu().tolist()

            if isinstance(batch_scores, float):
                batch_scores = [batch_scores]
            scores.extend(batch_scores)

        return scores

    def _remote_rerank(self, query: str, candidates: List[RRFResult]) -> List[float]:
        """远程推理服务重排"""
        import httpx

        endpoint = get_settings().reranker_endpoint
        pairs = [[query, c.content] for c in candidates]

        response = httpx.post(
            f"{endpoint}/rerank",
            json={"query": query, "documents": [c.content for c in candidates]},
            timeout=30.0,
        )
        response.raise_for_status()
        return response.json()["scores"]

    def _mock_rerank(self, query: str, candidates: List[RRFResult]) -> List[float]:
        """
        Mock重排：基于RRF分数和简单的文本相似度生成模拟分数。

        模拟真实Reranker的行为：
        - 与查询有明确关键词匹配的结果给高分
        - 保留RRF分数的排序倾向
        """
        scores = []
        query_terms = set(query.lower().split())

        for candidate in candidates:
            # 计算简单的关键词重叠率
            content_terms = set(candidate.content.lower().split())
            overlap = len(query_terms & content_terms) / max(len(query_terms), 1)

            # 综合RRF分数和关键词重叠
            base_score = 0.5 + candidate.rrf_score * 50  # RRF分数贡献
            keyword_bonus = overlap * 0.3  # 关键词贡献

            # 加入一些确定性噪声（基于chunk_id的哈希）
            hash_noise = (hash(candidate.chunk_id) % 100) / 1000.0

            final_score = min(0.99, base_score + keyword_bonus + hash_noise)
            scores.append(final_score)

        return scores
