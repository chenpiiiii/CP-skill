"""
RRF（Reciprocal Rank Fusion）融合算法模块

核心算法：RRF(d) = 1/(k + R_bm25(d)) + 1/(k + R_vector(d))

RRF是一种无参数的排序融合方法，通过将不同检索系统的排名转换为倒数排名，
实现异构检索结果的统一排序。相比线性加权，RRF不需要对分数进行归一化，
对不同分布的分数更加鲁棒。

参数说明：
- k: RRF常数，默认为60，控制排名衰减速度
- bm25_weight: BM25权重，默认为1.0
- vector_weight: 向量检索权重，默认为1.0
"""

from __future__ import annotations

import logging
from typing import List, Optional, Dict, Tuple

from src.models.search_result import RetrievalResult, RRFResult, SearchSource

logger = logging.getLogger(__name__)


class RRFFusion:
    """
    RRF（倒数排名融合）算法实现

    将向量检索和BM25检索的结果列表融合为统一的排序列表。
    核心公式：RRF(d) = w_bm25 / (k + R_bm25(d)) + w_vec / (k + R_vec(d))

    其中：
    - R_bm25(d) 和 R_vec(d) 分别是文档d在两路检索中的排名（从1开始）
    - k 是平滑常数（默认60），避免高排名项权重过大
    - w_bm25 和 w_vec 是可选的权重因子
    """

    def __init__(
        self,
        k: int = 60,
        bm25_weight: float = 1.0,
        vector_weight: float = 1.0,
    ):
        """
        初始化RRF融合器。

        Args:
            k: RRF常数，控制排名衰减速度（默认60）
            bm25_weight: BM25检索权重
            vector_weight: 向量检索权重
        """
        self.k = k
        self.bm25_weight = bm25_weight
        self.vector_weight = vector_weight
        logger.info("RRF融合器初始化: k=%d, bm25_w=%.2f, vec_w=%.2f", k, bm25_weight, vector_weight)

    def fuse(
        self,
        bm25_results: List[RetrievalResult],
        vector_results: List[RetrievalResult],
    ) -> List[RRFResult]:
        """
        执行RRF融合。

        将BM25和向量检索的结果按RRF算法融合排序。
        同一文档如果在两路检索中都出现，其RRF分数为两路分数之和。

        Args:
            bm25_results: BM25检索结果（按分数降序排列）
            vector_results: 向量检索结果（按分数降序排列）

        Returns:
            RRF融合后的结果列表（按RRF分数降序排列）
        """
        if not bm25_results and not vector_results:
            return []

        # 构建 chunk_id → 排名 映射（排名从1开始）
        bm25_ranks: Dict[str, Tuple[int, float]] = {}
        for rank, result in enumerate(bm25_results, 1):
            bm25_ranks[result.chunk_id] = (rank, result.score)

        vector_ranks: Dict[str, Tuple[int, float]] = {}
        for rank, result in enumerate(vector_results, 1):
            vector_ranks[result.chunk_id] = (rank, result.score)

        # 收集所有出现的chunk_id
        all_chunk_ids = set(bm25_ranks.keys()) | set(vector_ranks.keys())
        logger.debug(
            "RRF融合: bm25=%d条, vector=%d条, 去重后=%d条",
            len(bm25_results), len(vector_results), len(all_chunk_ids),
        )

        # 计算每个文档的RRF分数
        rrf_results: List[RRFResult] = []

        for chunk_id in all_chunk_ids:
            bm25_rank, bm25_score = bm25_ranks.get(chunk_id, (None, 0.0))
            vector_rank, vector_score = vector_ranks.get(chunk_id, (None, 0.0))

            # RRF核心公式
            bm25_rrf = 0.0
            if bm25_rank is not None:
                bm25_rrf = self.bm25_weight / (self.k + bm25_rank)

            vector_rrf = 0.0
            if vector_rank is not None:
                vector_rrf = self.vector_weight / (self.k + vector_rank)

            total_rrf = bm25_rrf + vector_rrf

            # 获取元数据（优先从出现的那一路获取）
            source_result = None
            for r in bm25_results:
                if r.chunk_id == chunk_id:
                    source_result = r
                    break
            if source_result is None:
                for r in vector_results:
                    if r.chunk_id == chunk_id:
                        source_result = r
                        break

            rrf_results.append(RRFResult(
                chunk_id=chunk_id,
                content=source_result.content if source_result else "",
                rrf_score=total_rrf,
                bm25_rank=bm25_rank,
                vector_rank=vector_rank,
                bm25_score=bm25_score,
                vector_score=vector_score,
                document_id=source_result.document_id if source_result else "",
                document_name=source_result.document_name if source_result else "",
                hierarchy_path=source_result.hierarchy_path if source_result else "",
                page_range=source_result.page_range if source_result else [],
                category=source_result.category if source_result else "",
            ))

        # 按RRF分数降序排列
        rrf_results.sort(key=lambda x: x.rrf_score, reverse=True)

        # 更新排名
        for i, result in enumerate(rrf_results):
            result.rrf_score = round(result.rrf_score, 8)

        logger.info("RRF融合完成: 输入 %d 条候选 → 输出 %d 条", len(all_chunk_ids), len(rrf_results))
        return rrf_results

    def explain(self, chunk_id: str, bm25_rank: Optional[int], vector_rank: Optional[int]) -> str:
        """
        解释某个文档的RRF分数计算过程。

        Args:
            chunk_id: Chunk ID
            bm25_rank: BM25排名
            vector_rank: 向量排名

        Returns:
            计算过程的文字说明
        """
        parts = [f"RRF计算说明 (k={self.k}):"]

        bm25_rrf = 0.0
        if bm25_rank is not None:
            bm25_rrf = self.bm25_weight / (self.k + bm25_rank)
            parts.append(f"  BM25: {self.bm25_weight} / ({self.k} + {bm25_rank}) = {bm25_rrf:.6f}")
        else:
            parts.append("  BM25: 未命中")

        vector_rrf = 0.0
        if vector_rank is not None:
            vector_rrf = self.vector_weight / (self.k + vector_rank)
            parts.append(f"  Vector: {self.vector_weight} / ({self.k} + {vector_rank}) = {vector_rrf:.6f}")
        else:
            parts.append("  Vector: 未命中")

        total = bm25_rrf + vector_rrf
        parts.append(f"  总分: {total:.6f}")

        return "\n".join(parts)
