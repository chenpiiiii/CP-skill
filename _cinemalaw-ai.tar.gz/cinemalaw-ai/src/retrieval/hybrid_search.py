"""
混合检索编排器

编排双路检索 → RRF融合 → Rerank的完整混合检索流程。
提供统一的search接口，屏蔽底层检索细节。
"""

from __future__ import annotations

import time
import logging
from typing import List, Optional, Dict, Any

from config.settings import get_settings
from src.models.search_result import (
    RetrievalResult, RRFResult, RerankResult, SearchResult, SearchSource,
)
from src.retrieval.vector_search import VectorSearcher
from src.retrieval.bm25_search import BM25Searcher
from src.retrieval.rrf_fusion import RRFFusion
from src.retrieval.reranker import Reranker

logger = logging.getLogger(__name__)


class HybridSearcher:
    """
    混合检索编排器

    完整检索流程：
    1. Query预处理（可选的Query改写/扩展）
    2. 并行执行双路检索（向量 + BM25）
    3. RRF融合排序
    4. Reranker精排
    5. 返回Top-K结果

    延迟预算：P95 ≤ 500ms（不含LLM生成）
    """

    def __init__(
        self,
        vector_searcher: Optional[VectorSearcher] = None,
        bm25_searcher: Optional[BM25Searcher] = None,
        rrf_fusion: Optional[RRFFusion] = None,
        reranker: Optional[Reranker] = None,
        use_mock: bool = False,
    ):
        """
        初始化混合检索器。

        Args:
            vector_searcher: 向量检索器（不传则自动创建）
            bm25_searcher: BM25检索器（不传则自动创建）
            rrf_fusion: RRF融合器（不传则自动创建）
            reranker: 重排器（不传则自动创建）
            use_mock: 是否全部使用Mock模式
        """
        self.vector_searcher = vector_searcher or VectorSearcher(use_mock=use_mock)
        self.bm25_searcher = bm25_searcher or BM25Searcher(use_mock=use_mock)
        self.rrf_fusion = rrf_fusion or RRFFusion()
        self.reranker = reranker or Reranker(use_mock=use_mock)
        self.use_mock = use_mock
        logger.info("混合检索器初始化完成 (mock=%s)", use_mock)

    def search(
        self,
        query: str,
        top_k: int = 5,
        candidate_size: int = 30,
        metadata_filter: Optional[Dict[str, Any]] = None,
        enable_rerank: bool = True,
    ) -> SearchResult:
        """
        执行混合检索。

        Args:
            query: 用户查询
            top_k: 最终返回条数
            candidate_size: 每路检索的候选数量
            metadata_filter: 元数据过滤条件
            enable_rerank: 是否启用Reranker

        Returns:
            完整的检索结果
        """
        start_time = time.time()
        logger.info("开始混合检索: query='%s', top_k=%d", query[:50], top_k)

        # 步骤1：并行双路检索
        t1 = time.time()
        vector_results = self.vector_searcher.search(query, top_k=candidate_size, metadata_filter=metadata_filter)
        bm25_results = self.bm25_searcher.search(query, top_k=candidate_size, metadata_filter=metadata_filter)
        retrieval_time = (time.time() - t1) * 1000
        logger.info(
            "双路检索完成: vector=%d条, bm25=%d条, 耗时=%.1fms",
            len(vector_results), len(bm25_results), retrieval_time,
        )

        # 步骤2：RRF融合
        t2 = time.time()
        fused_results = self.rrf_fusion.fuse(bm25_results, vector_results)
        fusion_time = (time.time() - t2) * 1000
        logger.info("RRF融合完成: %d条, 耗时=%.1fms", len(fused_results), fusion_time)

        # 步骤3：Reranker精排
        if enable_rerank and fused_results:
            t3 = time.time()
            final_results = self.reranker.rerank(query, fused_results, top_k=top_k)
            rerank_time = (time.time() - t3) * 1000
            logger.info("Rerank完成: %d条, 耗时=%.1fms", len(final_results), rerank_time)
        else:
            # 不使用reranker时，直接取RRF分数最高的top_k
            final_results = [
                RerankResult(
                    chunk_id=r.chunk_id,
                    content=r.content,
                    rerank_score=r.rrf_score,
                    rrf_score=r.rrf_score,
                    rank=i,
                    document_id=r.document_id,
                    document_name=r.document_name,
                    hierarchy_path=r.hierarchy_path,
                    page_range=r.page_range,
                    category=r.category,
                )
                for i, r in enumerate(fused_results[:top_k])
            ]

        total_time = (time.time() - start_time) * 1000

        return SearchResult(
            query=query,
            results=final_results,
            total_candidates=len(vector_results) + len(bm25_results),
            search_time_ms=total_time,
            search_metadata={
                "vector_results": len(vector_results),
                "bm25_results": len(bm25_results),
                "fused_results": len(fused_results),
                "retrieval_time_ms": retrieval_time,
                "fusion_time_ms": fusion_time,
                "enable_rerank": enable_rerank,
            },
        )

    def search_with_query_expansion(
        self,
        query: str,
        expanded_queries: List[str],
        top_k: int = 5,
        candidate_size: int = 30,
    ) -> SearchResult:
        """
        带查询扩展的混合检索（HyDE策略）。

        Args:
            query: 原始查询
            expanded_queries: 扩展后的查询列表
            top_k: 最终返回条数
            candidate_size: 每路检索的候选数量

        Returns:
            融合后的检索结果
        """
        # 对原始查询和扩展查询分别检索
        all_results = []
        queries = [query] + expanded_queries

        for q in queries:
            result = self.search(q, top_k=top_k, candidate_size=candidate_size)
            all_results.append(result)

        # 合并所有结果（按rerank_score去重取最优）
        seen_chunks: Dict[str, RerankResult] = {}
        for result in all_results:
            for r in result.results:
                if r.chunk_id not in seen_chunks or r.rerank_score > seen_chunks[r.chunk_id].rerank_score:
                    seen_chunks[r.chunk_id] = r

        # 按分数排序取top_k
        final_results = sorted(seen_chunks.values(), key=lambda x: x.rerank_score, reverse=True)[:top_k]
        for i, r in enumerate(final_results):
            r.rank = i

        total_time = sum(r.search_time_ms for r in all_results)

        return SearchResult(
            query=query,
            rewritten_query=" | ".join(queries),
            results=final_results,
            total_candidates=sum(r.total_candidates for r in all_results),
            search_time_ms=total_time,
            search_metadata={"expanded_queries": len(expanded_queries)},
        )

    def get_search_stats(self) -> Dict[str, Any]:
        """获取检索器统计信息"""
        return {
            "vector_searcher": {
                "mock": self.vector_searcher.use_mock,
                "embedder_mock": self.vector_searcher.embedder.use_mock,
            },
            "bm25_searcher": {
                "mock": self.bm25_searcher.use_mock,
            },
            "rrf_fusion": {
                "k": self.rrf_fusion.k,
                "bm25_weight": self.rrf_fusion.bm25_weight,
                "vector_weight": self.rrf_fusion.vector_weight,
            },
            "reranker": {
                "mock": self.reranker.use_mock,
                "threshold": self.reranker.threshold,
                "top_k": self.reranker.top_k,
            },
        }
