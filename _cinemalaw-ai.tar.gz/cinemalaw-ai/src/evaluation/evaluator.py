"""
RAGAS评估器模块

集成RAGAS评估框架，计算Faithfulness、Answer Relevance、Context Recall等核心指标。
"""

from __future__ import annotations

import logging
from typing import List, Dict, Any, Optional

from src.models.response import RAGResponse

logger = logging.getLogger(__name__)


class RAGASEvaluator:
    """
    RAGAS评估器

    使用RAGAS框架评估RAG系统的生成质量：
    - Faithfulness（忠实度）: 回答是否完全基于检索到的上下文，目标≥95%
    - Answer Relevance（回答相关性）: 回答是否切题，目标≥90%
    - Context Recall（上下文召回率）: 检索是否覆盖了回答所需的信息，目标≥92%
    """

    def __init__(self, judge_llm: Optional[str] = None):
        """
        初始化RAGAS评估器。

        Args:
            judge_llm: 用于评估的LLM，不传则使用配置
        """
        from config.settings import get_settings
        settings = get_settings()
        self.judge_llm = judge_llm or settings.ragas_judge_llm
        self._stats = {"evaluations_run": 0, "samples_evaluated": 0}
        logger.info("RAGAS评估器初始化: judge_llm=%s", self.judge_llm)

    def evaluate_single(
        self,
        question: str,
        answer: str,
        contexts: List[str],
        ground_truth: Optional[str] = None,
    ) -> Dict[str, float]:
        """
        评估单个问答样本。

        Args:
            question: 用户问题
            answer: 系统回答
            contexts: 检索到的上下文列表
            ground_truth: 标准答案（可选）

        Returns:
            各指标分数字典
        """
        scores: Dict[str, float] = {}

        # Faithfulness: 检查回答中的声明是否都有上下文支撑
        scores["faithfulness"] = self._evaluate_faithfulness(answer, contexts)

        # Answer Relevance: 检查回答是否切题
        scores["answer_relevance"] = self._evaluate_answer_relevance(question, answer)

        # Context Recall: 如果有ground_truth，检查上下文覆盖率
        if ground_truth:
            scores["context_recall"] = self._evaluate_context_recall(ground_truth, contexts)
        else:
            scores["context_recall"] = -1.0  # 无法计算

        self._stats["evaluations_run"] += 1
        self._stats["samples_evaluated"] += 1

        logger.info("评估结果: faithfulness=%.3f, relevance=%.3f, recall=%.3f",
                     scores["faithfulness"], scores["answer_relevance"], scores["context_recall"])
        return scores

    def evaluate_batch(
        self,
        samples: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """
        批量评估。

        Args:
            samples: 评估样本列表，每个包含 question/answer/contexts/ground_truth

        Returns:
            汇总评估结果
        """
        all_scores: Dict[str, List[float]] = {
            "faithfulness": [],
            "answer_relevance": [],
            "context_recall": [],
        }

        for i, sample in enumerate(samples):
            logger.info("评估样本 %d/%d", i + 1, len(samples))
            scores = self.evaluate_single(
                question=sample["question"],
                answer=sample["answer"],
                contexts=sample["contexts"],
                ground_truth=sample.get("ground_truth"),
            )
            for metric, score in scores.items():
                if score >= 0:
                    all_scores[metric].append(score)

        # 计算汇总统计
        summary = {}
        for metric, score_list in all_scores.items():
            if score_list:
                summary[metric] = {
                    "mean": sum(score_list) / len(score_list),
                    "min": min(score_list),
                    "max": max(score_list),
                    "count": len(score_list),
                    "pass_rate": sum(1 for s in score_list if s >= 0.9) / len(score_list),
                }
            else:
                summary[metric] = {"mean": 0, "min": 0, "max": 0, "count": 0, "pass_rate": 0}

        self._stats["samples_evaluated"] += len(samples)
        return summary

    def evaluate_from_response(self, response: RAGResponse) -> Dict[str, float]:
        """
        从RAGResponse对象中提取评估数据并评估。

        Args:
            response: RAG响应对象

        Returns:
            指标分数字典
        """
        contexts = [c["content"] for c in response.context_chunks]
        return self.evaluate_single(
            question=response.query,
            answer=response.answer,
            contexts=contexts,
        )

    def _evaluate_faithfulness(self, answer: str, contexts: List[str]) -> float:
        """
        评估忠实度：回答中的声明是否都有上下文支撑。

        简化实现：使用关键词重叠率近似计算。
        生产环境应使用RAGAS框架的完整实现。
        """
        if not contexts:
            return 0.0

        # 合并所有上下文
        all_context = " ".join(contexts)
        context_terms = set(all_context)

        # 检查回答中的关键句是否在上下文中有支撑
        sentences = [s.strip() for s in answer.replace("。", "。\n").split("\n") if s.strip()]
        if not sentences:
            return 1.0

        supported_count = 0
        for sentence in sentences:
            # 简单检查：句子中是否有足够的上下文关键词
            overlap = sum(1 for char in sentence if char in context_terms)
            coverage = overlap / max(len(sentence), 1)
            if coverage > 0.3:  # 阈值
                supported_count += 1

        return supported_count / len(sentences)

    def _evaluate_answer_relevance(self, question: str, answer: str) -> float:
        """
        评估回答相关性：回答是否切题。

        简化实现：检查问题和回答之间的关键词重叠。
        """
        q_terms = set(question)
        a_terms = set(answer)

        if not q_terms or not a_terms:
            return 0.0

        overlap = len(q_terms & a_terms)
        relevance = overlap / max(len(q_terms), 1)
        return min(1.0, relevance * 2)  # 放大系数，上限1.0

    def _evaluate_context_recall(self, ground_truth: str, contexts: List[str]) -> float:
        """
        评估上下文召回率：上下文是否覆盖了标准答案所需的信息。

        简化实现：检查标准答案中的关键词是否出现在上下文中。
        """
        if not contexts:
            return 0.0

        all_context = " ".join(contexts)
        gt_chars = set(ground_truth)

        if not gt_chars:
            return 1.0

        found = sum(1 for c in gt_chars if c in all_context)
        return found / len(gt_chars)

    def get_stats(self) -> Dict[str, Any]:
        """获取评估统计"""
        return dict(self._stats)
