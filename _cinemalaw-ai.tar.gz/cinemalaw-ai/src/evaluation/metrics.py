"""
评估指标定义与趋势分析模块
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


# 指标阈值定义
METRIC_THRESHOLDS = {
    "faithfulness": {"target": 0.95, "warning": 0.90, "critical": 0.85},
    "answer_relevance": {"target": 0.90, "warning": 0.85, "critical": 0.80},
    "context_recall": {"target": 0.92, "warning": 0.87, "critical": 0.82},
}


@dataclass
class MetricSnapshot:
    """指标快照（单次评估结果）"""
    timestamp: datetime = field(default_factory=datetime.utcnow)
    faithfulness: float = 0.0
    answer_relevance: float = 0.0
    context_recall: float = 0.0
    sample_count: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp.isoformat(),
            "faithfulness": self.faithfulness,
            "answer_relevance": self.answer_relevance,
            "context_recall": self.context_recall,
            "sample_count": self.sample_count,
        }


@dataclass
class MetricTrend:
    """指标趋势分析"""
    metric_name: str
    snapshots: List[MetricSnapshot] = field(default_factory=list)
    window_size: int = 7  # 滑动窗口大小

    @property
    def latest_value(self) -> float:
        if not self.snapshots:
            return 0.0
        return getattr(self.snapshots[-1], self.metric_name, 0.0)

    @property
    def moving_average(self) -> float:
        if not self.snapshots:
            return 0.0
        recent = self.snapshots[-self.window_size:]
        values = [getattr(s, self.metric_name, 0.0) for s in recent]
        return sum(values) / len(values) if values else 0.0

    @property
    def trend_direction(self) -> str:
        if len(self.snapshots) < 2:
            return "stable"
        recent = self.snapshots[-3:]
        values = [getattr(s, self.metric_name, 0.0) for s in recent]
        if values[-1] > values[0] + 0.02:
            return "improving"
        elif values[-1] < values[0] - 0.02:
            return "degrading"
        return "stable"

    def check_thresholds(self) -> Dict[str, str]:
        thresholds = METRIC_THRESHOLDS.get(self.metric_name, {})
        current = self.latest_value
        status = "pass"
        if current < thresholds.get("critical", 0):
            status = "critical"
        elif current < thresholds.get("warning", 0):
            status = "warning"
        elif current < thresholds.get("target", 0):
            status = "below_target"
        return {"metric": self.metric_name, "value": f"{current:.3f}", "status": status}


class MetricsTracker:
    """指标追踪器"""

    def __init__(self):
        self.trends: Dict[str, MetricTrend] = {
            "faithfulness": MetricTrend("faithfulness"),
            "answer_relevance": MetricTrend("answer_relevance"),
            "context_recall": MetricTrend("context_recall"),
        }

    def record(self, snapshot: MetricSnapshot) -> None:
        for name, trend in self.trends.items():
            trend.snapshots.append(snapshot)

    def get_status(self) -> Dict[str, Any]:
        return {name: trend.check_thresholds() for name, trend in self.trends.items()}
