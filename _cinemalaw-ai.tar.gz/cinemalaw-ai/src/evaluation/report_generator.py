"""
评估报告生成模块

生成Markdown/HTML格式的评估报告。
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Dict, Any, Optional, List
from pathlib import Path

logger = logging.getLogger(__name__)


class ReportGenerator:
    """评估报告生成器"""

    def generate_markdown(
        self,
        summary: Dict[str, Any],
        details: Optional[List[Dict[str, Any]]] = None,
        output_path: Optional[str] = None,
    ) -> str:
        """
        生成Markdown格式的评估报告。

        Args:
            summary: 评估汇总结果
            details: 各样本的详细评估结果
            output_path: 输出文件路径（可选）

        Returns:
            Markdown报告文本
        """
        now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        lines = [
            f"# 影律通 RAG 评估报告",
            f"",
            f"**生成时间**: {now} UTC",
            f"",
            f"## 指标概览",
            f"",
            f"| 指标 | 均值 | 最小值 | 最大值 | 样本数 | 达标率(≥90%) |",
            f"|------|------|--------|--------|--------|-------------|",
        ]

        thresholds = {
            "faithfulness": 0.95,
            "answer_relevance": 0.90,
            "context_recall": 0.92,
        }

        for metric_name, data in summary.items():
            if isinstance(data, dict) and "mean" in data:
                target = thresholds.get(metric_name, 0.9)
                lines.append(
                    f"| {metric_name} | {data['mean']:.3f} | {data['min']:.3f} "
                    f"| {data['max']:.3f} | {data['count']} | {data.get('pass_rate', 0):.1%} |"
                )

        lines.extend([
            "",
            "## 指标说明",
            "",
            "- **Faithfulness（忠实度）**: 回答是否完全基于检索到的上下文，目标 ≥ 95%",
            "- **Answer Relevance（回答相关性）**: 回答是否准确切题，目标 ≥ 90%",
            "- **Context Recall（上下文召回率）**: 检索是否覆盖了回答所需信息，目标 ≥ 92%",
            "",
            "## 达标标准",
            "",
        ])

        # 达标判断
        all_pass = True
        for metric_name, threshold in thresholds.items():
            data = summary.get(metric_name, {})
            mean_val = data.get("mean", 0) if isinstance(data, dict) else 0
            status = "✅ 达标" if mean_val >= threshold else "❌ 未达标"
            if mean_val < threshold:
                all_pass = False
            lines.append(f"- {metric_name}: {mean_val:.3f} (目标 {threshold}) → {status}")

        lines.extend([
            "",
            f"## 总结",
            "",
            f"**整体评估状态**: {'✅ 全部达标' if all_pass else '⚠️ 部分指标未达标，需要优化'}",
            "",
            "---",
            "*本报告由影律通RAGAS评估系统自动生成*",
        ])

        report = "\n".join(lines)

        if output_path:
            Path(output_path).write_text(report, encoding="utf-8")
            logger.info("评估报告已保存: %s", output_path)

        return report

    def generate_html(self, summary: Dict[str, Any], output_path: Optional[str] = None) -> str:
        """生成HTML格式的评估报告"""
        md_report = self.generate_markdown(summary)
        html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>影律通评估报告</title>
<style>body{{font-family:sans-serif;max-width:800px;margin:0 auto;padding:20px;}}
table{{border-collapse:collapse;width:100%;}}th,td{{border:1px solid #ddd;padding:8px;text-align:left;}}
th{{background:#f4f4f4;}}.pass{{color:green;}}.fail{{color:red;}}</style></head>
<body><pre>{md_report}</pre></body></html>"""

        if output_path:
            Path(output_path).write_text(html, encoding="utf-8")
        return html
